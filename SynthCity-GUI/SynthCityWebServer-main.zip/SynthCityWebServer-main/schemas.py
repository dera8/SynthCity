from __future__ import annotations
from enum import Enum
from typing import Any,Dict, List, Optional, Union, Literal
from pydantic import BaseModel, Field, RootModel


class GTFSSubFileType(Enum):
    route = "routes.txt"
    stop = "stops.txt"

class Route(BaseModel):
    id: Optional[int] = 0
    route_id: str
    route_name: str
    route_type: int

class Stop(BaseModel):
    id: Optional[int] = 0
    is_deleted: Optional[bool] = False
    stop_id: str
    stop_name: str
    is_deleted: bool
    stop_lat: str
    stop_long: str

class FileInfo(BaseModel):
    fileName: str
    fileId: int
    fileType: str
    fileStatus: str
    filePath: str


class Road(BaseModel):
    name: Optional[str]
    edgeId: str
    path: List[Coordinates]

class GroupedRoad(BaseModel):
    name: str
    edges: List[Edge]
    @staticmethod
    def wrapRoad(road: Road):
        edges = []
        edges.append(Edge(edgeId=road.edgeId,path=road.path))
        return GroupedRoad(name=road.name,edges=edges)


class Edge(BaseModel):
    edgeId: str
    path: List[Coordinates]

class RoadClosure(BaseModel):
    name: str
    startTime: str
    endTime: str

class RoadClosureDB(BaseModel):
    roadId: int
    edgeId: str
    name: str
    startTime: str
    endTime: str

class Coordinates(BaseModel):
    latitude: float
    longitude: float
    @staticmethod
    def serialize_coordinates(coords_list: List[Coordinates]):
        return [{"latitude": coord.latitude, "longitude": coord.longitude} for coord in coords_list]
    @staticmethod
    def deserialize_coordinates(coords_data: List[dict]) -> List["Coordinates"]:
        return [Coordinates(**coord) for coord in coords_data]


class NetworkInfo(BaseModel):
    type: Literal["network_info"]
    mapCenter: Coordinates
    roadList: Optional[Union[PaginatedRoads,PaginatedGroupedRoads]] = None

class PaginatedRoads(BaseModel):
    roads: List[Road]
    paginator: Paginator

class PaginatedGroupedRoads(BaseModel):
    roads: List[GroupedRoad]
    paginator: Paginator

class PaginatedClosedRoads(BaseModel):
    type: Literal["paginated_closed_roads"]
    roads: List[RoadClosure]
    paginator: Paginator

class Paginator(BaseModel):
    page: int
    pageSize: int
    totalCount: int
    totalPages: int

class UploadFileRequest(BaseModel):
    file: bytes
    fileName: str



class StopsInfo(BaseModel):
    type: Literal["stops_info"]
    stops: List[Stop]




class TripsInfo(BaseModel):
    type: Literal["trips_info"]
    trips: List[Route]


class GtfsInfo(BaseModel):
    type: Literal["gtfs_info"]
    tripsInfo: TripsInfo
    stopsInfo: StopsInfo


class OdMatrixInfo(BaseModel):
    type: Literal["od_matrix_info"]
    zones: List[str]


class FullFileInfo(BaseModel):
    fileInfo: FileInfo
    fileData: Union[NetworkInfo, StopsInfo, TripsInfo, GtfsInfo, OdMatrixInfo, PaginatedClosedRoads, TripTypes] | None = Field(...,discriminator="type") 


class TripTypes(BaseModel):
    type: Literal["trip_types"]
    types: List[str]
class UpdateProjectRequest(BaseModel):
    action: str
    fileId: List[str]


class Error(BaseModel):
    message: str


class FileFileIdGetResponse(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class FileFileIdGetResponse2(BaseModel):
    message: str


class FileFileIdDeleteResponse(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class FileFileIdDeleteResponse1(BaseModel):
    message: str


class FileFileIdPutResponse(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class FileFileIdPutResponse2(BaseModel):
    message: str


class UploadFileIdStatusGetResponse(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class UploadFileIdStatusGetResponse1(BaseModel):
    message: str


class DownloadFileIdGetResponse(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class DownloadFileIdGetResponse1(BaseModel):
    message: str


class DownloadFileIdSubFileGetResponse(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class DownloadFileIdSubFileGetResponse1(BaseModel):
    message: str


class SubFile(Enum):
    agency = "agency"
    calendar = "calendar"
    trips = "trips"
    stops = "stops"
    calendarDate = "calendarDate"
    stopTimes = "stopTimes"


class FileFileIdSubFileGetResponse(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class FileFileIdSubFileGetResponse2(BaseModel):
    message: str


class UploadFileTypePostResponse(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class UploadFileTypePostResponse1(BaseModel):
    message: str


class FileType(str, Enum):
    gtfs = "gtfs"
    network = "network"
    odmatrix = "odmatrix"
    roadClosure = "roadClosure"
    edgeData = "edgeData"
    stopData = "stopData"
    tripData = "tripData"
    stopSim = "stopSim"
    TAZ = "TAZ"
    synthTrips = "synthTrips"
    synthEdges = "synthEdges"
    synthStops = "synthStops"

class FileStatus(str, Enum):
    created = "created"
    elaborating = "elaborating"
    completed = "completed"
    failed = "failed"

class ActionValueTypes(Enum):
    percentage = "percentage"
    value = "value"

class ActionCommandTypes(Enum):
    add = "add"
    sub = "subtract"
    
class ModifyGtfsTripsRequest(BaseModel):
    type: Literal["modify_gtfs_trips_request"]
    filename: str
    routes_ids: List[str]
    value: float

class ModifyGtfsStopsRequest(BaseModel):
    type: Literal["modify_gtfs_stops_request"]
    filename: str
    stops_ids: List[str]

class ModifyGtfsRequestBody(BaseModel):
    type: Literal["modify_gtfs_request"]
    request: Union[ModifyGtfsStopsRequest,ModifyGtfsTripsRequest]  = Field(...,discriminator="type")

class FileFileTypePostResponse(RootModel[Union[FileInfo, FullFileInfo]]): 
    pass


class FileFileTypePostResponse1(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class FileFileTypePostResponse2(BaseModel):
    message: str


class ProjectPostRequest(BaseModel):
    fileIds: List[int]


class ProjectPostResponse(BaseModel):
    projectId: str


class ProjectPostResponse1(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class ProjectPostResponse2(BaseModel):
    message: str


class ProjectProjectIdPutResponse(BaseModel):
    data: Dict[str, Any]


class ProjectProjectIdPutResponse1(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class ProjectProjectIdPutResponse2(BaseModel):
    message: str


class ProjectProjectIdGetResponse(BaseModel):
    files: List[FileInfo]


class ProjectProjectIdGetResponse1(BaseModel):
    message: str
    errors: Optional[List[Error]] = None


class ProjectProjectIdGetResponse2(BaseModel):
    message: str



class RoadClosureRequest(BaseModel):
    type: Literal["road_closure"]
    networkId: int
    roadList: List[RoadClosure]


class ModifyOdMatrixRequest(BaseModel):
    type: Literal["modify_od"]
    matrixId: int
    modifications: List[OdMatrixModification]
    actionValueType: ActionValueTypes
    newFileName: str

class SynthEdgesRequest(BaseModel):
    type: Literal["synth_edges"]
    edgeDataId: int
    tazFileId: int
    newFileName: str
    dateString: str

class SynthTripsRequest(BaseModel):
    type: Literal["synth_trips"]
    selectedTypes: List[str]
    tripFileId: int
    newFileName: str
    dateString: str

class SynthStopsRequest(BaseModel):
    type: Literal["synth_stops"]
    stopDataId: int
    stopSimId: int
    gtfsId: int
    arrivalDateString: str
    departureDateString: str
    newFileName: str
    infoStartDate: str

class OdMatrixModification(BaseModel):
    fromZone: str
    toZones: List[str]
    action: ActionCommandTypes
    value: int
    def serialize(self) -> str:
        to_zones_str = ",".join(self.toZones)
        return f"{self.fromZone}:{to_zones_str}:{self.action.value}:{self.value}"
class ErrorResponse(BaseModel):
    message: str    