"""Add edgeData to filetype enum

Revision ID: e9e0f40f359c
Revises: 5973a45c402c
Create Date: 2025-06-12 10:24:37.166211

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'e9e0f40f359c'
down_revision: Union[str, None] = '5973a45c402c'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("ALTER TYPE filetype ADD VALUE IF NOT EXISTS 'edgeData'")


def downgrade() -> None:
    #not supported in postgress, if necessary we need to create a new enum, migrate everything and then changeing the column type
    pass
