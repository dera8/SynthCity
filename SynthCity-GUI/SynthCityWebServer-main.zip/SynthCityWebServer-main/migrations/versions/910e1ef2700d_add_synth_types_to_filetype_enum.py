"""Add synth types  to filetype enum

Revision ID: 910e1ef2700d
Revises: 9927063ebb62
Create Date: 2025-06-12 11:02:56.824459

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '910e1ef2700d'
down_revision: Union[str, None] = '9927063ebb62'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("ALTER TYPE filetype ADD VALUE IF NOT EXISTS 'synthTrips'")
    op.execute("ALTER TYPE filetype ADD VALUE IF NOT EXISTS 'synthStops'")
    op.execute("ALTER TYPE filetype ADD VALUE IF NOT EXISTS 'synthEdges'")


def downgrade() -> None:
    #not supported in postgress, if necessary we need to create a new enum, migrate everything and then changeing the column type
    pass

