"""Add stopData tripData stopSim  to filetype enum

Revision ID: 9927063ebb62
Revises: 8420f0a19ee4
Create Date: 2025-06-12 10:58:04.339548

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '9927063ebb62'
down_revision: Union[str, None] = '8420f0a19ee4'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None




def upgrade() -> None:
    op.execute("ALTER TYPE filetype ADD VALUE IF NOT EXISTS 'stopData'")
    op.execute("ALTER TYPE filetype ADD VALUE IF NOT EXISTS 'tripData'")
    op.execute("ALTER TYPE filetype ADD VALUE IF NOT EXISTS 'stopSim'")


def downgrade() -> None:
    #not supported in postgress, if necessary we need to create a new enum, migrate everything and then changeing the column type
    pass
