"""Add TAZ to filetype enum

Revision ID: 8420f0a19ee4
Revises: e9e0f40f359c
Create Date: 2025-06-12 10:46:21.604941

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '8420f0a19ee4'
down_revision: Union[str, None] = 'e9e0f40f359c'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("ALTER TYPE filetype ADD VALUE IF NOT EXISTS 'TAZ'")


def downgrade() -> None:
    #not supported in postgress, if necessary we need to create a new enum, migrate everything and then changeing the column type
    pass
