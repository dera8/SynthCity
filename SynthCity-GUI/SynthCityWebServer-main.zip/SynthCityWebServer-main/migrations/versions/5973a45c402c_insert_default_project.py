"""insert default project

Revision ID: 5973a45c402c
Revises: 6cfb158a2ca8
Create Date: 2025-04-18 10:14:35.129067

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '5973a45c402c'
down_revision: Union[str, None] = '6cfb158a2ca8'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    op.execute(
        """
        INSERT INTO projects (id, name, description, created_at)
        VALUES (1, 'Default Project', 'This is the default project', CURRENT_TIMESTAMP)
        """
    )

def downgrade():
    op.execute("DELETE FROM projects WHERE id = 1")
