"""default id

Revision ID: 7c39e9742266
Revises: efa2619f446f
Create Date: 2025-03-03 16:13:01.068912

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '7c39e9742266'
down_revision: Union[str, None] = 'efa2619f446f'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    op.execute(
        """
        INSERT INTO projects (id, name, description, created_at)
        VALUES (1, 'Default Project', 'This is the default project', CURRENT_TIMESTAMP)
        """
    )

def downgrade():
    op.execute("DELETE FROM projects WHERE id = 1")

