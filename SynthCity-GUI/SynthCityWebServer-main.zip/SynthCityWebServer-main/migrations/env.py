import asyncio
from logging.config import fileConfig
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy import pool
from alembic import context

# Import your database models
from database import Base
from models import *  # Ensure all models are imported

# Load Alembic config
config = context.config

# Interpret the config file for Python logging
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Set target metadata for Alembic migrations
target_metadata = Base.metadata

# Retrieve the database URL from Alembic config
DATABASE_URL = config.get_main_option("sqlalchemy.url")

# Ensure correct async database URL (fix for SQLite and PostgreSQL)
if DATABASE_URL.startswith("sqlite:///"):
    DATABASE_URL = DATABASE_URL.replace("sqlite:///", "sqlite+aiosqlite:///")

def include_object(object, name, type_, reflected, compare_to):
    if reflected:
        return False
    return True


# Function to run migrations offline
def run_migrations_offline():
    """Run migrations in 'offline' mode (without a DB connection)."""
    context.configure(
        url=DATABASE_URL,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()

# Function to actually run migrations
def do_run_migrations(connection):
    """Run actual migrations."""
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        compare_type=True,
        include_object=include_object,
    )

    with context.begin_transaction():
        context.run_migrations()

# Function to run migrations online (async mode)
async def run_migrations_online():
    """Run migrations in 'online' mode with an async DB connection."""
    connectable = create_async_engine(DATABASE_URL, future=True, poolclass=pool.NullPool)

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

if context.is_offline_mode():
    run_migrations_offline()
else:
    asyncio.run(run_migrations_online())
