import asyncio
import json
import os
import pathlib
import shutil
import sys
import time
from typing import Tuple
import xml.etree.ElementTree as ET

from fastapi import Query
from models import FileTypeMapping, NetworkFile
from schemas import *
from scripts import Anomaly_Creation_Scripts
from services.file import FileService
from services.gis import GisService
from services.utils import ceildiv

if 'SUMO_HOME' in os.environ:
    tools_path = os.path.join(os.environ['SUMO_HOME'], 'tools')
    if tools_path not in sys.path:
        sys.path.append(tools_path)
else:
    raise EnvironmentError("Please set the SUMO_HOME environment variable to your SUMO installation directory.")

from database import SessionLocal
from repositories import NetworkRepository, FileTypeMappingRepository, RoadClosureItemRepository, RoadRepository, RoadClosureFileRepository
import sumolib  # type: ignore

class NetworkService:
    @staticmethod
    async def parse_network(path: str, fileId: int):
        data = await asyncio.to_thread(NetworkService._parse_network_sync, path)
        road_list = data.roadList.roads
        status = FileStatus.completed
        async with SessionLocal() as db:
                try:
                    async with db.begin(): 
                        for road_data in road_list:
                            await RoadRepository.transactional_create(
                                db,
                                network_id=fileId,
                                path=GisService.get_geom_from_coordinates(road_data.path),
                                edge_id=road_data.edgeId,
                                name=road_data.name
                            )

                except Exception as e:
                    print(f"Transaction failed {e}")
                    status = FileStatus.failed            
                file = await FileTypeMappingRepository.update(db,file_id=fileId,file_status=status)
                
                    
        return file
    @staticmethod
    def retrieve_network_center(path: str) -> Coordinates:
        net = sumolib.net.readNet(path)
        minX, minY, maxX, maxY = net.getBoundary()
        minLon, minLat = net.convertXY2LonLat(minX, minY)
        maxLon, maxLat = net.convertXY2LonLat(maxX, maxY)
        center_lon = (minLon + maxLon) / 2.0
        center_lat = (minLat + maxLat) / 2.0
        mapCenter = Coordinates(latitude=center_lat, longitude=center_lon)
        return mapCenter
    @staticmethod
    def _parse_network_sync(path: str):
        net = sumolib.net.readNet(path)

    # -------------------------
    # Compute map center using the original boundary
    # -------------------------

        minX, minY, maxX, maxY = net.getBoundary()
        minLon, minLat = net.convertXY2LonLat(minX, minY)
        maxLon, maxLat = net.convertXY2LonLat(maxX, maxY)
        center_lon = (minLon + maxLon) / 2.0
        center_lat = (minLat + maxLat) / 2.0
        mapCenter = Coordinates(latitude=center_lat, longitude=center_lon)


    # -------------------------
    # Extract street edges
    # -------------------------
        streets: List[Road] = []
        count = 0  # Limit for testing; remove or adjust later.
        vehicle_highway_types = {
            "highway.motorway",
            "highway.motorway_link",
            "highway.trunk",
            "highway.trunk_link",
            "highway.primary",
            "highway.primary_link",
            "highway.secondary",
            "highway.secondary_link",
            "highway.tertiary",
            "highway.tertiary_link",
            "highway.residential",
            "highway.living_street",
            "highway.unclassified",
            "highway.service"
        }
        for edge in net.getEdges():
            if edge.getName() and edge.getShape() and edge.getType() in vehicle_highway_types:
                path: List[Coordinates] = []
                for point in edge.getShape():
                    x, y = point[0], point[1]
                    lon, lat = net.convertXY2LonLat(x, y)
                    coordinate = Coordinates(latitude=lat,longitude=lon)
                    if count == 0:
                        mapCenter = coordinate
                    path.append(coordinate)
                street = Road(name=edge.getName(),edgeId=edge.getID(),path=path)
                streets.append(street)
                count = count + 1

        # -------------------------
        # Create final output JSON structure
        # -------------------------

        return_data = NetworkInfo(type="network_info",mapCenter=mapCenter,roadList=PaginatedRoads(
            roads=streets,
            paginator=Paginator(
                page=1,
                pageSize=count,
                totalCount=count,
                totalPages=1
            )
        ))
        return return_data
    @staticmethod
    async def retrieve_network(fileId: int,  query: str, page: Optional[int] = Query(1, ge=1), page_size: Optional[int] = Query(50, ge=1)) -> NetworkInfo:
        async with SessionLocal() as db:
            network: NetworkFile = await NetworkRepository.get_by_id(db,fileId)
            res: Tuple[List[GroupedRoad], int] = await NetworkService.retrieve_roads_by_network(fileId=fileId,page=page,page_size=page_size,query=query)
            response = NetworkInfo(
                type="network_info",
                mapCenter=Coordinates(
                    latitude=network.center_latitude,
                    longitude=network.center_longitude,
                ),
                roadList=PaginatedGroupedRoads(
                    roads=res[0],
                    paginator=Paginator(
                        page=page,
                        pageSize=page_size,
                        totalCount=res[1],
                        totalPages=ceildiv(res[1],page_size)
                    )
                )
            )
            return response
    @staticmethod
    async def retrieve_roads_by_network(fileId: int, page: Optional[int] = Query(1, ge=1), page_size: Optional[int] = Query(50, ge=1), query: Optional[str] = "") -> Tuple[List[GroupedRoad], int]:
        async with SessionLocal() as db:
            offset = (page - 1) * page_size
            res = await RoadRepository.get_grouped_by_network_paginated_w_query(db, fileId, offset, page_size,query)
            roadsDb = res[0]
            total_count = res[1]
            roads: List[GroupedRoad] = []
            if roadsDb:
                for roadName in roadsDb:
                    edgesDB = await RoadRepository.get_by_network_and_name(db,fileId,roadName)
                    edges = []
                    for edge in edgesDB:
                        edges.append(Edge(edgeId=edge.edge_id,path=GisService.get_coordinates_from_geom(edge.path)))
                    roads.append(GroupedRoad(name=roadName,edges=edges))

            return roads, total_count
    @staticmethod
    async def retrieve_closed_roads(closure_file_id: int, page: Optional[int] = Query(1, ge=1), page_size: Optional[int] = Query(50, ge=1)) -> Tuple[List[RoadClosure], int]:
        async with SessionLocal() as db:
            offset = (page - 1) * page_size
            roadsDb = await RoadClosureItemRepository.get_by_road_closure_paginated(db, closure_file_id, offset, page_size)
            total_count = await RoadClosureItemRepository.get_total_count_by_road_closure(db, closure_file_id)

            roads: List[RoadClosure] = []
            if roadsDb:
                for road in roadsDb:
                    roadDb = await RoadRepository.get_by_id(db,road.road_id)
                    roads.append(RoadClosure(
                        name=roadDb.name,
                        startTime=road.start_hour,
                        endTime=road.end_hour
                    ))

            return roads, total_count    
    @staticmethod
    async def close_roads(networkId: int,roadClosures: List[RoadClosure], fileClosureId: int) -> FileTypeMapping:
        closureFolder = pathlib.Path("files") / FileType.roadClosure.value
        closureFolder.mkdir(parents=True, exist_ok=True)
        netFile = await FileService.retrieve_file(networkId,FileType.network,FileStatus.completed)
        subfolder = pathlib.Path("files") / "temp" / f"network_{networkId}_{int(time.time())}"
        subfolder.mkdir(parents=True, exist_ok=True)
        try:
            await asyncio.to_thread(NetworkService._close_roads_sync, netFile,subfolder,roadClosures)
        except Exception as err:
            print(err)
        resultPath =subfolder/ f"closure_{netFile.id}_{int(time.time())}.xml"
        finalName = f"{str(fileClosureId)}.xml"
        finalPath = closureFolder / f"{str(fileClosureId)}.xml"
        closures: List[RoadClosureDB] = await combine_xml_files(subfolder,resultPath)
        shutil.copy2(str(resultPath),str(finalPath))
        shutil.rmtree(str(subfolder))
        status = FileStatus.completed
        async with SessionLocal() as db:
            try:
                async with db.begin():
                    closureFile = await RoadClosureFileRepository.transactional_create(db,file_id=fileClosureId,name=finalName,network_id=netFile.id,project_id=netFile.project_id)
                    for closure in closures:
                        inserted = await RoadClosureItemRepository.transactional_create(db,closureFile.file_id,closure.roadId,closure.startTime,closure.endTime)
            except Exception as e:
                print(f"Transaction failed {e}")
                status = FileStatus.failed            
        updated = await FileTypeMappingRepository.update(db,file_id=fileClosureId,file_status=status,filepath=str(finalPath),filename=finalName)
        return updated
    @staticmethod
    def _close_roads_sync(netFile: FileTypeMapping,subfolder: pathlib.Path,roadClosures: List[RoadClosure]):
        for roadClosure in roadClosures:
            file_path = subfolder / f"close-{roadClosure.name}.xml"
            result = Anomaly_Creation_Scripts.close_roads.road_closure_management(netFile.filepath, roadClosure.name,roadClosure.startTime,roadClosure.endTime,str(file_path))
            if result != "ok":
                raise result
    @staticmethod
    async def retrieve_road_closure(fileId: int,page: Optional[int] = Query(1, ge=1), page_size: Optional[int] = Query(50, ge=1)) -> PaginatedClosedRoads:
         async with SessionLocal() as db:
            res: Tuple[List[RoadClosure], int] = await NetworkService.retrieve_closed_roads(closure_file_id=fileId,page=page,page_size=page_size)
            response = PaginatedClosedRoads(
                type="paginated_closed_roads",
                roads=res[0],
                paginator=Paginator(
                    page=page,
                    pageSize=page_size,
                    totalCount=res[1],
                    totalPages=ceildiv(res[1],page_size)
                )
            )
            return response


async def combine_xml_files(folder_path: pathlib.Path, output_file: pathlib.Path) -> List[RoadClosureDB]:
    """
    Combines all XML files in the given folder into a single XML file with continuous rerouter IDs.

    :param folder_path: Path to the folder containing XML files.
    :param output_file: Path for the output combined XML file.
    """
    root = ET.Element("additional")
    current_id = 1

    xml_files = sorted([f for f in os.listdir(folder_path) if f.endswith(".xml")])
    rerouter_list: List[RoadClosureDB] = []
    for file in xml_files:
        file_path = os.path.join(folder_path, file)
        tree = ET.parse(file_path)
        file_root = tree.getroot()
        for rerouter in file_root.findall("rerouter"):
            rerouter.set("id", str(current_id))  
            edge_id = rerouter.get("edges")
            
            interval = rerouter.find("interval")
            if interval is not None:
                start_time = interval.get("begin")  
                end_time = interval.get("end")      
                async with SessionLocal() as db:
                    road = await RoadRepository.get_by_edge_id(db,edge_id)
                    rerouter_list.append(RoadClosureDB(
                        roadId=road.id,
                        name=road.name,
                        edgeId=edge_id,
                        startTime=start_time,
                        endTime=end_time
                    ))
            root.append(rerouter)
            current_id += 1  


    combined_tree = ET.ElementTree(root)


    with open(output_file, "wb") as f:
        f.write(b'<?xml version="1.0" ?>\n') 
        combined_tree.write(f, encoding="utf-8")
    return rerouter_list

