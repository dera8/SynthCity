import asyncio
import csv
import os
import pathlib
import shutil
import tempfile
import time
from typing import Dict, List, Type, Union
import zipfile

from database import SessionLocal
from repositories.file_mappings import FileTypeMappingRepository
from repositories.gtfs import GtfsRepository
from schemas import FileStatus, GTFSSubFileType, ModifyGtfsStopsRequest, ModifyGtfsTripsRequest, Route, Stop
from scripts.Anomaly_Creation_Scripts import delete_percentage_of_trips
from scripts.Anomaly_Creation_Scripts.delete_gtfs_stops import delete_stops
from services.utils import get_unique_path
from models import GTFSRoutes, GTFSStops


ROUTE_MAPPING = {
    "route_id": "route_id",
    "route_name": "route_long_name",
    "route_type": "route_type",
}

STOP_MAPPING = {
    "stop_id": "stop_id",
    "stop_name": "stop_name",
    "stop_desc": "stop_desc",
    "stop_lat": "stop_lat",
    "stop_long": "stop_lon",
}

class GtfsService:
    @staticmethod
    def modify_gtfs_trips(file_id: int, file_path: str, request: ModifyGtfsTripsRequest) -> pathlib.Path:
        routes = request.routes_ids
        filename = request.filename
        current_file=file_path
        subfolder = pathlib.Path("files") / "temp" / f"gtfs_{file_id}_{int(time.time())}"
        subfolder.mkdir(parents=True, exist_ok=True)
        for route_id in routes:
            resultPath =subfolder/ f"delete_trip_{route_id}_{int(time.time())}.zip"
            num_deleted = delete_percentage_of_trips(gtfs_zip=current_file,route_id=route_id,percentage=request.value,output_zip=str(resultPath))
            print(f"for {route_id}, deleted {num_deleted}")
            current_file = resultPath
        final_path =  get_unique_path(pathlib.Path("files") / "gtfs" / filename)
        shutil.copy2(str(resultPath),str(final_path))
        shutil.rmtree(str(subfolder))
        return final_path

    @staticmethod
    async def delete_gtfs_stops(file_id: int, file_path: str, request: ModifyGtfsStopsRequest) -> pathlib.Path:
        stops = request.stops_ids
        filename = request.filename
        final_path =  get_unique_path(pathlib.Path("files") / "gtfs" / filename)
        deleted_stops = delete_stops(gtfs_file=file_path,stops_to_delete=stops,output_file=str(final_path))
        async with SessionLocal() as db:
            for stop_id in deleted_stops:
                await GtfsRepository.update_stop_by_stop_id(db,stop_id=stop_id,file_id=file_id,is_deleted=True)
        return final_path

    @staticmethod
    async def parse_gtfs_subfile(path: str, file_id: int, sub_file: GTFSSubFileType) -> Union[List[Route],List[Stop]]:
        status = FileStatus.completed
        print("sub_file:",sub_file)
        async with SessionLocal() as db:
            try:
                async with db.begin():
                    match sub_file:
                        case GTFSSubFileType.route:
                            data = unzip_and_parse_csv(path,sub_file.value, Route, ROUTE_MAPPING)
                            result: List[Route] = []
                            for route in data:
                                new_route = await GtfsRepository.transactional_create_route(db,route.route_id,route.route_name,route.route_type,file_id)
                                result.append(Route(
                                    id=new_route.id,
                                    route_id=new_route.route_id,
                                    route_name=new_route.route_name,
                                    route_type=new_route.route_type,
                                ))
                        case GTFSSubFileType.stop:
                            data = unzip_and_parse_csv(path,sub_file.value, Stop, STOP_MAPPING)
                            result: List[Stop] = []
                            for stop in data:
                                new_stop = await GtfsRepository.transactional_create_stop(
                                    db=db,
                                    stop_id=stop.stop_id,
                                    stop_name=stop.stop_name,
                                    stop_lat=stop.stop_lat,
                                    stop_long=stop.stop_long,
                                    is_deleted=stop.is_deleted,
                                    file_id=file_id
                                )
                                result.append(Stop(
                                    id=new_stop.id,
                                    stop_id=new_stop.stop_id,
                                    stop_name=new_stop.stop_name,
                                    is_deleted=new_stop.is_deleted,
                                    stop_lat=new_stop.stop_lat,
                                    stop_long=new_stop.stop_long,
                                ))
            except Exception as e:
                print(f"Transaction failed {sub_file.name}: {e}")
                status = FileStatus.failed
        await FileTypeMappingRepository.update(db,file_id=file_id,file_status=status)
        return result

    @staticmethod
    async def get_stops_by_gtfs_id(gtfs_id: int) -> List[Stop]:
        async with SessionLocal() as db:
            stops =  await GtfsRepository.get_stops_by_file_id(db,gtfs_id)
            result: List[Stop] = []
            for stop in stops:
                result.append(Stop(
                    id=stop.id,
                    stop_id=stop.stop_id,
                    stop_name=stop.stop_name,
                    is_deleted=stop.is_deleted,
                    stop_lat=stop.stop_lat,
                    stop_long=stop.stop_long,
                ))
        return result
    
    @staticmethod
    async def get_routes_by_gtfs_id(gtfs_id: int) -> List[Stop]:
        async with SessionLocal() as db:
            routes =  await GtfsRepository.get_routes_by_file_id(db,gtfs_id)
            result: List[Route] = []
            for route in routes:
                result.append(Route(
                    id=route.id,
                    route_id=route.route_id,
                    route_name=route.route_name,
                    route_type=route.route_type,
                ))
        return result


def unzip_and_parse_csv(zip_path: str, csv_filename: str, model: Type, field_map: Dict[str, str]):
    data = []
    
    with tempfile.TemporaryDirectory() as tmpdirname:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(tmpdirname)
        
        csv_path = os.path.join(tmpdirname, csv_filename)
        
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"CSV file '{csv_filename}' not found in the zip archive.")
        
        with open(csv_path, mode='r', encoding='utf-8') as csv_file:
            reader = csv.DictReader(csv_file)
            for row in reader:
                data.append(model(**{attr: row.get(csv_field) for attr, csv_field in field_map.items()}))
    
    return data           