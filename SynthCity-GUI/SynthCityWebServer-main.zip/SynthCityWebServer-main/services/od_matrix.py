class OdMatrixService:
    @staticmethod
    def parseOdMatrix(path: str) -> set:
        zones = set()
        with open(path, 'r') as file:
            for line in file:
                line = line.strip()
                if not line or line.startswith('*') or ';' in line or line.startswith('$OR'):
                    continue
                parts = line.split()
                if len(parts) != 3:
                    continue

                try:
                    int(parts[1])
                    int(parts[0])
                    origin, destination = parts[0], parts[1]
                    zones.add(origin)
                    zones.add(destination)
                except ValueError as err:
                    print(f"Error parsing {line}: {err}\n")
        return zones
