from typing import List
from geoalchemy2 import WKBElement
from shapely.geometry import LineString
from geoalchemy2.shape import from_shape
from geoalchemy2.shape import to_shape

from schemas import Coordinates


class GisService:
    @staticmethod
    def get_geom_from_coordinates(coordinates: List[Coordinates]) -> WKBElement:
        coords = [(point.longitude, point.latitude) for point in coordinates]
        linestring = LineString(coords)
        return from_shape(linestring, srid=4326)
    
    @staticmethod
    def get_coordinates_from_geom(geom: WKBElement) -> List[Coordinates]:
        line: LineString = to_shape(geom)
        return [Coordinates(latitude=lat, longitude=lon) for lon, lat in line.coords]