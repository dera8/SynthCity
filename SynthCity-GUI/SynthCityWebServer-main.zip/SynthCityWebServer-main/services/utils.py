import pathlib
import xml.etree.ElementTree as ET
import os
import zipfile

def ceildiv(a, b):
    return -(a // -b)

def unzip_file(zip_path: str, extract_to: str=None):
    """
    Unzips a zip file to the specified directory.

    :param zip_path: Path to the .zip file
    :param extract_to: Directory to extract files to. If None, extracts to the same directory as zip file.
    :return: List of extracted file paths
    """
    if extract_to is None:
        extract_to = os.path.splitext(zip_path)[0]  # Default to folder with same name as zip

    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)
        return zip_ref.namelist()

def get_unique_path(filepath: pathlib.Path) -> pathlib.Path:
    path = filepath
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        return path
    
    stem, suffix = path.stem, path.suffix
    parent = path.parent
    count = 1
    new_path = parent / f"{stem}-{count}{suffix}"

    while new_path.exists():
        count += 1
        new_path = parent / f"{stem}-{count}{suffix}"
    return new_path

def get_unique_types_and_vtypes(xml_file):
        """Retrieve unique 'type' and 'vType' values from the XML file."""
        print(f"parsing file {xml_file}\n")
        tree = ET.parse(xml_file)
        root = tree.getroot()

        types = set()
        vtypes = set()

        print(f"analyizing tree\n")
        for tripinfo in root.findall('tripinfo'):
            type_value = tripinfo.attrib.get('type')
            vtype_value = tripinfo.attrib.get('vType')
            
            if type_value:
                types.add(type_value)
            if vtype_value:
                vtypes.add(vtype_value)

        return sorted(types), sorted(vtypes)