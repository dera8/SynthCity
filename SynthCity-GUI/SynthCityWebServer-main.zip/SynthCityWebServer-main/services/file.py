import os
from typing import List, Optional
from database import SessionLocal
from models import FileTypeMapping
from repositories.file_mappings import FileTypeMappingRepository
from schemas import FileStatus, FileType

class FileService:
    @staticmethod
    async def retrieve_file(file_id: int, file_type: FileType = None, file_status: FileStatus = None):
        file = await FileService._retrieve_file_basic(file_id)

        if file_type and FileType(file.file_type).value != file_type.value:
            raise FileExceptions.WrongType(file_id, file_type.value, FileType(file.file_type).value)
        
        if file_status and FileStatus(file.file_status).value != file_status.value:
            raise FileExceptions.WrongStatus(file_id, file_status.value, FileStatus(file.file_status).value)
        
        return file

    @staticmethod
    async def _retrieve_file_basic(file_id: int):
        """Helper function to fetch a file from the database."""
        async with SessionLocal() as db:
            file = await FileTypeMappingRepository.get_by_id(db, file_id)
        if not file:
            raise FileExceptions.NotFound(file_id)
        return file
    @staticmethod
    async def create_file(file_type: FileType,filename: str,filepath: str) -> Optional[FileTypeMapping]:
        """Helper function to create a file in the database."""
        async with SessionLocal() as db:
            new_file = await FileTypeMappingRepository.create(db=db,project_id=1,filename=filename,file_type=file_type,filepath=filepath,file_status=FileStatus.created)
        if not new_file:
            raise FileExceptions.CreationError(filepath)
        return new_file
    @staticmethod
    async def retrieve_files_by_project(project_id: int) ->List[FileTypeMapping]:
        async with SessionLocal() as db:
            files = await FileTypeMappingRepository.get_by_project_id(db=db,project_id=project_id)
        if not files:
            return []
        else:
            return files
    @staticmethod    
    async def cancel_file_by_id(file_id: int) -> bool:
        async with SessionLocal() as db:
            file = await FileService._retrieve_file_basic(file_id)
            os.remove(file.filepath)
            return await FileTypeMappingRepository.delete_by_id(db=db,file_id=file_id)

    

class FileException(Exception):
    """Custom exception for file service failures."""
    def __init__(self, message="file service exception"):
        self.message = message
        super().__init__(self.message)

class FileExceptions(FileException):
    class NotFound(FileException):
        """Raised when a file is not found."""
        def __init__(self, file_id):
            super().__init__(f"File with ID '{file_id}' not found")
    class WrongType(FileException):
        """Raised when a file is not of the wanted type."""
        def __init__(self, file_id, wanted, got):
            super().__init__(f"File with ID '{file_id}' is not of type '{wanted}' but of type '{got}'")
    class WrongStatus(FileException):
        """Raised when a file is not in the wanted status"""
        def __init__(self, file_id, wanted, got):
            super().__init__(f"File with ID '{file_id}' is not '{wanted}': current status '{got}'")
    class CreationError(FileException):
        """Raised when there was an error creating the file"""
        def __init__(self, filepath):
            super().__init__(f"Error creating file '{filepath}'")