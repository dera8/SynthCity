# SynthCityWebServer
This is the backend server of the SynthCityWeb application.
It stores the file generated with the application or uploaded by the user in the `files` folder, while the data is stored in a sqlite database.