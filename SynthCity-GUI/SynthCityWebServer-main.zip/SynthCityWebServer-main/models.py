from geoalchemy2 import Geometry
from sqlalchemy import JSON, Boolean, Column, Integer, String, ForeignKey, DateTime, func, Enum as PgEnum
from sqlalchemy.orm import relationship
from database import Base
from schemas import FileStatus, FileType

class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    description = Column(String, index=True)
    created_at = Column(DateTime, default=func.now())
    
    road_closures = relationship("RoadClosureFile", back_populates="project", cascade="all, delete-orphan", passive_deletes=True)
    files = relationship("FileTypeMapping", back_populates="project", cascade="all, delete-orphan",)

class FileTypeMapping(Base):
    __tablename__ = "file_type_mapping"

    id = Column(Integer, primary_key=True, index=True)
    file_status = Column(PgEnum(FileStatus, name="filestatus"), nullable=False)
    file_type = Column(PgEnum(FileType, name="filetype"), nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    filename = Column(String, index=True)
    filepath = Column(String)
    created_at = Column(DateTime, default=func.now())

    project = relationship("Project", back_populates="files")
    network_file = relationship("NetworkFile", back_populates="file", uselist=False, passive_deletes=True)
    closure_file = relationship("RoadClosureFile", back_populates="file", uselist=False, passive_deletes=True)

class NetworkFile(Base):
    __tablename__ = "network_files"

    file_id = Column(Integer, ForeignKey("file_type_mapping.id", ondelete="CASCADE"), primary_key=True)
    center_latitude = Column(String)
    center_longitude = Column(String)
    file = relationship("FileTypeMapping", back_populates="network_file")
    roads = relationship("Road", back_populates="network", cascade="all, delete-orphan")
    road_closures = relationship("RoadClosureFile", back_populates="network", cascade="all, delete-orphan")

class Road(Base):
    __tablename__ = "roads"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    edge_id = Column(String, nullable=False)
    network_id = Column(Integer, ForeignKey("network_files.file_id", ondelete="CASCADE"), nullable=False)
    path = Column(Geometry(geometry_type="LINESTRING", srid=4326), nullable=False)
    created_at = Column(DateTime, default=func.now())

    network = relationship("NetworkFile", back_populates="roads")
    closure_entries = relationship("ClosureFileRoad", back_populates="road", cascade="all, delete-orphan", passive_deletes=True)

class RoadClosureFile(Base):
    __tablename__ = "road_closure_files"

    file_id = Column(Integer, ForeignKey("file_type_mapping.id", ondelete="CASCADE"), primary_key=True)
    name = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now())
    network_id = Column(Integer, ForeignKey("network_files.file_id", ondelete="CASCADE"), nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    
    file = relationship("FileTypeMapping", back_populates="closure_file")
    network = relationship("NetworkFile", back_populates="road_closures")
    project = relationship("Project", back_populates="road_closures")
    closure_roads = relationship("ClosureFileRoad", back_populates="closure_file", cascade="all, delete-orphan", passive_deletes=True)

class ClosureFileRoad(Base):
    __tablename__ = "closure_file_roads"

    id = Column(Integer, primary_key=True, index=True)
    closure_file_id = Column(Integer, ForeignKey("road_closure_files.file_id", ondelete="CASCADE"), nullable=False)
    road_id = Column(Integer, ForeignKey("roads.id", ondelete="CASCADE"), nullable=False)
    start_hour = Column(String, nullable=False)
    end_hour = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now())

    closure_file = relationship("RoadClosureFile", back_populates="closure_roads")
    road = relationship("Road", back_populates="closure_entries")

class GTFSRoutes(Base):
    __tablename__ = "gtfs_routes"
    id = Column(Integer, primary_key=True, index=True)
    route_id = Column(String, index=True, nullable=False)
    route_name = Column(String, nullable=False, index=True)
    route_type = Column(Integer,default=0)
    file_id = Column(Integer, ForeignKey("file_type_mapping.id", ondelete="CASCADE"), nullable=False)

class GTFSStops(Base):
    __tablename__ = "gtfs_stops"
    id = Column(Integer, primary_key=True, index=True)
    stop_id = Column(String, index=True, nullable=False)
    stop_name = Column(String, nullable=False, index=True)
    stop_lat = Column(String)
    stop_long = Column(String)
    is_deleted = Column(Boolean, default=False)
    file_id = Column(Integer, ForeignKey("file_type_mapping.id", ondelete="CASCADE"), nullable=False)