from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from models import FileTypeMapping
from schemas import FileStatus, FileType

class FileTypeMappingRepository:
    @staticmethod
    async def create(
        db: AsyncSession, 
        project_id: int, 
        filename: str, 
        file_status: FileStatus, 
        file_type: FileType, 
        filepath: Optional[str]
    ) -> Optional[FileTypeMapping]:
        try:
            file_mapping = FileTypeMapping(
                project_id=project_id,
                filename=filename,
                file_status=file_status,
                file_type=file_type,
                filepath=filepath
            )
            db.add(file_mapping)
            await db.commit()
            await db.flush()
            await db.refresh(file_mapping)
            return file_mapping
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            raise

    @staticmethod
    async def get_by_id(db: AsyncSession, file_id: int) -> Optional[FileTypeMapping]:
        result = await db.execute(select(FileTypeMapping).filter(FileTypeMapping.id == file_id))
        return result.scalars().first()
    @staticmethod
    async def get_by_project_id(db: AsyncSession, project_id: int) ->Optional[List[FileTypeMapping]]:
        result = await db.execute(select(FileTypeMapping).filter(FileTypeMapping.project_id == project_id))
        return result.scalars().all()
    @staticmethod
    async def update(
        db: AsyncSession, 
        file_id: int, 
        filename: Optional[str] = None,
        filepath: Optional[str] = None, 
        file_status: Optional[FileStatus] = None, 
    ) -> Optional[FileTypeMapping]:
        """Update a file mapping entry in the database."""
        try:
            result = await db.execute(select(FileTypeMapping).where(FileTypeMapping.id == file_id))
            file_mapping = result.scalars().first()

            if not file_mapping:
                return None

            if filename:
                file_mapping.filename=filename
            if filepath:
                file_mapping.filepath=filepath
            if file_status:
                file_mapping.file_status=file_status
            

            await db.commit()
            await db.flush()
            await db.refresh(file_mapping)
            return file_mapping
        except Exception as e:
            await db.rollback()
            print(f"Database update error: {e}")
            raise
    @staticmethod
    async def delete_by_id(db: AsyncSession, file_id: int) -> bool:
        """Delete a file mapping entry by its ID."""
        try:
            result = await db.execute(select(FileTypeMapping).where(FileTypeMapping.id == file_id))
            file_mapping = result.scalars().first()

            if not file_mapping:
                return False

            await db.delete(file_mapping)
            await db.flush()
            await db.commit()
            return True
        except Exception as e:
            await db.rollback()
            print(f"Database deletion error: {e}")
            raise
