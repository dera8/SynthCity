from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from models import Project
from schemas import FileStatus, FileType

class ProjectRepository:
    @staticmethod
    async def create(
        db: AsyncSession, 
        name: str,
        description: str
    ) -> Optional[Project]:
        try:
            project = Project(
                name=name,
                description=description
            )
            db.add(project)
            await db.commit()
            await db.flush()
            await db.refresh(project)
            return project
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            raise

    @staticmethod
    async def get_by_id(db: AsyncSession, project_id: int) -> Optional[Project]:
        result = await db.execute(select(Project).filter(Project.id == project_id))
        return result.scalars().first()