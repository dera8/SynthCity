from typing import Optional, List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from models import NetworkFile


class NetworkRepository:
    @staticmethod
    async def transactional_create(
        db: AsyncSession, 
        network_id: int,
        center_lat: str, 
        center_long: str
    ) -> Optional[NetworkFile]:
        try:
            network = NetworkFile(
                file_id=network_id,
                center_latitude=center_lat,
                center_longitude=center_long
            )
            db.add(network)
            await db.flush()
            await db.refresh(network)
            return network
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            raise

    @staticmethod
    async def create(
        db: AsyncSession, 
        network_id: int,
        center_lat: str, 
        center_long: str
    ) -> Optional[NetworkFile]:
        try:
            network = NetworkFile(
                file_id=network_id,
                center_latitude=center_lat,
                center_longitude=center_long
            )
            db.add(network)
            await db.flush()
            await db.refresh(network)
            await db.commit()
            return network
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            raise

    @staticmethod
    async def get_by_project(db: AsyncSession, project_id: int) -> List[NetworkFile]:
        result = await db.execute(select(NetworkFile).filter(NetworkFile.project_id == project_id))
        return result.scalars().all()

    @staticmethod
    async def get_by_id(db: AsyncSession, network_id: int) -> Optional[NetworkFile]:
        result = await db.execute(
            select(NetworkFile).options(selectinload(NetworkFile.roads)).where(NetworkFile.file_id == network_id)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def update(
        db: AsyncSession, 
        network_id: int, 
        center_lat: Optional[str] = None, 
        center_long: Optional[str] = None
    ) -> Optional[NetworkFile]:
        try:
            result = await db.execute(select(NetworkFile).filter(NetworkFile.file_id == network_id))
            network = result.scalars().first()

            if not network:
                return None

            if center_lat:
                network.center_latitude = center_lat
            if center_long:
                network.center_longitude = center_long

            await db.commit()
            await db.flush()
            await db.refresh(network)
            return network
        except Exception as e:
            await db.rollback()
            print(f"Database update error: {e}")
            raise

    @staticmethod
    async def delete(db: AsyncSession, network_id: int) -> bool:
        try:
            result = await db.execute(select(NetworkFile).filter(NetworkFile.file_id == network_id))
            network = result.scalars().first()

            if not network:
                return False

            await db.delete(network)
            await db.commit()
            return True
        except Exception as e:
            await db.rollback()
            print(f"Database delete error: {e}")
            return False
