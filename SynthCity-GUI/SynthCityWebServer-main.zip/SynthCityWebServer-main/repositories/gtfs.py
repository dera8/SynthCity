from typing import Optional
from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession

from models import GTFSRoutes, GTFSStops
from schemas import Route

class GtfsRepository:
    @staticmethod
    async def transactional_create_route(
        db: AsyncSession,
        route_id: str,
        route_name: str,
        route_type: int,
        file_id: int,
    ) -> Optional[GTFSRoutes]:
        try:
            route = GTFSRoutes(
                route_id=route_id,
                route_name=route_name,
                route_type=route_type,
                file_id=file_id,
            )
            db.add(route)
            await db.flush()
            await db.refresh(route)
            return route
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            return None
    @staticmethod
    async def transactional_create_stop(
        db: AsyncSession,
        stop_id: str,
        stop_name: str,
        stop_lat: str,
        stop_long: str,
        is_deleted: bool,
        file_id: int,
    ) -> Optional[GTFSStops]:
        try:
            stop = GTFSStops(
                stop_id=stop_id,
                stop_name=stop_name,
                stop_lat=stop_lat,
                stop_long=stop_long,
                is_deleted=is_deleted,
                file_id =file_id,
            )
            db.add(stop)
            await db.flush()
            await db.refresh(stop)
            return stop
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            return None
    @staticmethod
    async def get_by_stop_id(db: AsyncSession, stop_id: str, file_id: int) -> Optional[GTFSStops]:
        result = await db.execute(select(GTFSStops).filter(GTFSStops.file_id == file_id).filter(GTFSStops.stop_id == stop_id))
        return result.scalars().first()
    @staticmethod
    async def update_stop_by_stop_id(
        db: AsyncSession,
        stop_id: str,
        file_id: int,
        stop_name: Optional[str] = None,
        stop_lat: Optional[str] = None,
        stop_long: Optional[str] = None,
        is_deleted: Optional[bool] = None,
    ) -> Optional[GTFSStops]:
        try:
            stop = await GtfsRepository.get_by_stop_id(db,stop_id=stop_id,file_id=file_id)
            if not stop:
                return None
            if stop_name:
                stop.stop_name=stop_name
            if stop_lat:
                stop.stop_lat=stop_lat
            if stop_long:
                stop.stop_long=stop_long
            if is_deleted:
                stop.is_deleted=is_deleted
            await db.commit()
            await db.flush()
            await db.refresh(stop)
            return stop
        except Exception as e:
            await db.rollback()
            print(f"Database update error: {e}")
            raise
    @staticmethod
    async def get_stops_by_file_id(db: AsyncSession, file_id: int) -> Optional[list[GTFSStops]]:
        try:
            result = await db.execute(
                select(GTFSStops).filter(GTFSStops.file_id == file_id)
            )
            return result.scalars().all()
        except Exception as e:
            await db.rollback()
            print(f"Database update error: {e}")
            raise
    @staticmethod
    async def get_routes_by_file_id(db: AsyncSession, file_id: int) -> Optional[list[GTFSRoutes]]:
        try:
            result = await db.execute(
                select(GTFSRoutes).filter(GTFSRoutes.file_id == file_id)
            )
            return result.scalars().all()
        except Exception as e:
            await db.rollback()
            print(f"Database update error: {e}")
            raise
    

