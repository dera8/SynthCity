
from typing import List, Optional
from geoalchemy2 import WKBElement
from sqlalchemy import func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from models import ClosureFileRoad, Road, RoadClosureFile


class RoadRepository:
    @staticmethod
    async def create(
        db: AsyncSession,
        network_id: int,
        path: WKBElement,
        edge_id: str,
        name: str
    ) -> Optional[Road]:
        try:
            road = Road(
                network_id=network_id,
                path=path,
                edge_id=edge_id,
                name=name
            )
            db.add(road)
            await db.commit()
            await db.flush()
            await db.refresh(road)
            return road
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            raise
    @staticmethod
    async def transactional_create(
        db: AsyncSession,
        network_id: int,
        path: WKBElement,
        edge_id: str,
        name: str
    ) -> Optional[Road]:
        try:
            road = Road(
                network_id=network_id,
                path=path,
                edge_id=edge_id,
                name=name
            )
            db.add(road)
            await db.flush()
            await db.refresh(road)
            return road
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            raise
    @staticmethod
    async def get_by_network(db: AsyncSession, network_id: int) -> List[Road]:
        result = await db.execute(select(Road).filter(Road.network_id == network_id))
        return result.scalars().all()

    @staticmethod
    async def get_by_id(db: AsyncSession, road_id: int) -> Optional[Road]:
        result = await db.execute(select(Road).filter(Road.id == road_id))
        return result.scalars().first()
    
    @staticmethod
    async def get_by_edge_id(db: AsyncSession, edge_id: str) -> Optional[Road]:
        result = await db.execute(select(Road).filter(Road.edge_id == edge_id))
        return result.scalars().first()
    
    @staticmethod
    async def get_by_name(db: AsyncSession, name: str) -> List[Road]:
        result = await db.execute(select(Road).filter(Road.name == name))
        return result.scalars().all()

    @staticmethod
    async def update(
        db: AsyncSession,
        road_id: str,
        path: Optional[str] = None, 
        edge_id: Optional[str] = None, 
        name: Optional[str] = None, 
    ) -> Optional[Road]:
        try:
            result = await db.execute(select(Road).filter(Road.id == road_id))
            road = result.scalars().first()

            if not road:
                return None

            if path:
                road.path = path
            if edge_id:
                road.edge_id = edge_id
            if name:
                road.name = name

            await db.commit()
            await db.flush()
            await db.refresh(road)
            return road
        except Exception as e:
            await db.rollback()
            print(f"Database update error: {e}")
            raise

    @staticmethod
    async def delete(db: AsyncSession, road_id: int) -> bool:
        try:
            result = await db.execute(select(Road).filter(Road.id == road_id))
            network = result.scalars().first()

            if not network:
                return False

            await db.delete(network)
            await db.commit()
            return True
        except Exception as e:
            await db.rollback()
            print(f"Database delete error: {e}")
            return False
    @staticmethod
    async def get_by_network_paginated(db: AsyncSession, fileId: int, offset: int, limit: int):
        stmt = (
            select(Road)
            .filter_by(network_id=fileId) 
            .order_by(Road.edge_id) 
            .offset(offset)
            .limit(limit)
        )
        result = await db.execute(stmt)
        return result.scalars().all()
    @staticmethod
    async def get_by_network_and_name(db: AsyncSession, fileId: int, name: str):
        stmt = (
            select(Road)
            .filter_by(network_id=fileId) 
            .filter_by(name=name)
        )
        result = await db.execute(stmt)
        return result.scalars().all()
    @staticmethod
    async def get_grouped_by_network_paginated(db: AsyncSession, network_id: int, offset: int, limit: int):
        stmt = (
            select(
                Road.name
            )
            .where(Road.network_id == network_id)
            .group_by(Road.name)
            .order_by(Road.name)
            .offset(offset)
            .limit(limit)
        )

        result = await db.execute(stmt)
        return result.all()
    @staticmethod
    async def get_grouped_by_network_paginated_w_query(db: AsyncSession, network_id: int, offset: int, limit: int, query: str):
        # 1. Subquery for grouped names
        grouped_subq = (
            select(Road.name)
            .where(Road.network_id == network_id)
            .where(Road.name.ilike(f"%{query}%"))
            .group_by(Road.name)
            .subquery()
        )

        # 2. Count total number of grouped rows
        count_stmt = select(func.count()).select_from(grouped_subq)
        total_result = await db.execute(count_stmt)
        total_count = total_result.scalar()

        # 3. Fetch paginated results from the grouped subquery
        paginated_stmt = (
            select(grouped_subq.c.name)
            .order_by(grouped_subq.c.name)
            .offset(offset)
            .limit(limit)
        )
        results = await db.execute(paginated_stmt)
        names = results.scalars().all()
        return names, total_count
    @staticmethod
    async def get_grouped_by_network(db: AsyncSession, network_id: int):
        stmt = (
            select(
                Road.name
            )
            .where(Road.network_id == network_id)
            .group_by(Road.name)
            .order_by(Road.name)
        )

        result = await db.execute(stmt)
        return result.all()

    @staticmethod
    async def get_total_count_by_network(db: AsyncSession, fileId: int):
        stmt = select(func.count()).select_from(Road).filter_by(network_id=fileId).group_by(Road.name)
        result = await db.execute(stmt)
        return result.scalar()


class RoadClosureItemRepository:
    @staticmethod
    async def create(
        db: AsyncSession,
        road_closure_file_id: int,
        road_id: int,
        start_hour: str,
        end_hour: str
    ) -> Optional[ClosureFileRoad]:
        try:
            roadClosure = ClosureFileRoad(
                closure_file_id=road_closure_file_id,
                road_id=road_id,
                start_hour=start_hour,
                end_hour=end_hour,
            )
            db.add(roadClosure)
            await db.commit()
            await db.flush()
            await db.refresh(roadClosure)
            return roadClosure
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            raise
    @staticmethod
    async def transactional_create(
        db: AsyncSession,
        road_closure_file_id: int,
        road_id: int,
        start_hour: str,
        end_hour: str
    ) -> Optional[ClosureFileRoad]:
        try:
            roadClosure = ClosureFileRoad(
                closure_file_id=road_closure_file_id,
                road_id=road_id,
                start_hour=start_hour,
                end_hour=end_hour,
            )
            db.add(roadClosure)
            return roadClosure
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            return None 
    @staticmethod
    async def get_by_road_closure_paginated(db: AsyncSession, fileId: int, offset: int, limit: int):
        stmt = (
            select(ClosureFileRoad)
            .filter_by(closure_file_id=fileId) 
            .order_by(ClosureFileRoad.road_id) 
            .offset(offset)
            .limit(limit)
        )
        result = await db.execute(stmt)
        return result.scalars().all()
    @staticmethod
    async def get_total_count_by_road_closure(db: AsyncSession, fileId: int):
        stmt = select(func.count()).select_from(ClosureFileRoad).filter_by(closure_file_id=fileId)
        result = await db.execute(stmt)
        return result.scalar()



class RoadClosureFileRepository:
    @staticmethod
    async def create(
        db: AsyncSession,
        name: str,
        file_id: int,
        network_id: int,
        project_id: int,
    ) -> Optional[RoadClosureFile]:
        try:
            closureFile = RoadClosureFile(
                file_id=file_id,
                name=name,
                network_id=network_id,
                project_id=project_id,
            )
            db.add(closureFile)
            await db.commit()
            await db.flush()
            await db.refresh(closureFile)
            return closureFile
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            raise
class RoadClosureFileRepository:
    @staticmethod
    async def transactional_create(
        db: AsyncSession,
        name: str,
        file_id: int,
        network_id: int,
        project_id: int,
    ) -> Optional[RoadClosureFile]:
        try:
            closureFile = RoadClosureFile(
                file_id=file_id,
                name=name,
                network_id=network_id,
                project_id=project_id,
            )
            db.add(closureFile)
            await db.flush()
            await db.refresh(closureFile)
            return closureFile
        except Exception as e:
            await db.rollback()
            print(f"Database error: {e}")
            raise