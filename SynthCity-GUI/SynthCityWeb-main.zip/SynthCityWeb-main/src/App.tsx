import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import TitleBar from "./components/Titlebar";
import Sidebar from "./components/Sidebar";
import ModifyGTFS from "./pages/ModifyGTFS/ModifyGTFS";
import ModifyRoutes from "./pages/ModifyGTFS/ModifyRoutes";
import DeleteStops from "./pages/ModifyGTFS/DeleteStops";
import RoadClosure from "./pages/RoadClosure/RoadClosure";
import DataGeneration from "./pages/DataGeneration/DataGeneration";
import StopGeneration from "./pages/DataGeneration/StopGeneration";
import EdgeGeneration from "./pages/DataGeneration/EdgeGeneration";
import TripGeneration from "./pages/DataGeneration/TripGeneration";
import ModifyOdMatrices from "./pages/OdMatrices/ModifyOdMatrices";
import Home from "./pages/Home/Home";
import Dashboard from "./pages/Dashboard/Dashboard";

const App = () => {
  return (
    <Router>
      <div className="h-screen flex flex-col">
        <TitleBar />
        <div className="flex flex-1">
          <Sidebar />
          <div className="flex-1 overflow-x-hidden">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/modify-gtfs" element={<ModifyGTFS />}>
                <Route index element={<Navigate to="routes" />} />
                <Route path="routes" element={<ModifyRoutes />} />
                <Route path="stops" element={<DeleteStops />} />
              </Route>
              <Route path="/close-roads" element={<RoadClosure />} />
              <Route path="/modify-matrices" element={<ModifyOdMatrices />} />
              <Route path="/data-generation" element={<DataGeneration />}>
                <Route index element={<Navigate to="stops" />} />
                <Route path="stops" element={<StopGeneration />} />
                <Route path="edges" element={<EdgeGeneration />} />
                <Route path="trips" element={<TripGeneration />} />
              </Route>
            </Routes>
          </div>
        </div>
      </div>
    </Router>
  );
};

export default App;
