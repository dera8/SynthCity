import { apiManager } from "../api/apiManager";
import { ApiError } from "../api/errors/apiError";
import { FileInfo, FileType, FullFileInfo } from "../api/generated";

export const uploadRepository = {
  async uploadFile(file: File, fileType: FileType): Promise<FullFileInfo> {
    try {
      const response = await apiManager.uploadApi.uploadFileUploadFileTypePost(
        fileType,
        file
      );
      return response.data as FullFileInfo;
    } catch (error: any) {
      throw ApiError.wrapError(error);
    }
  },

  async getUploadStatus(fileId: number): Promise<FileInfo> {
    try {
      const response =
        await apiManager.uploadApi.retrieveUploadStatusUploadFileIdStatusGet(
          fileId
        );
      return response.data as FileInfo;
    } catch (error: any) {
      throw ApiError.wrapError(error);
    }
  },
};
