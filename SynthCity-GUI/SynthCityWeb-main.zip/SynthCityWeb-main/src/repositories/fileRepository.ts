import { apiManager } from "../api/apiManager";
import { ApiError } from "../api/errors/apiError";
import {
  FileInfo,
  FileType,
  FullFileInfo,
  ModifyGtfsRequestBody,
  ModifyOdMatrixRequest,
  RoadClosureRequest,
  SynthEdgesRequest,
  SynthStopsRequest,
  SynthTripsRequest,
} from "../api/generated";

export const fileRepository = {
  async getFile(
    fileId: number,
    page?: number,
    pageSize?: number,
    query?: string
  ): Promise<FullFileInfo> {
    try {
      const response = await apiManager.fileApi.retrieveFileFileFileIdGet(
        fileId,
        page,
        pageSize,
        query
      );
      return response.data as FullFileInfo;
    } catch (error: any) {
      throw ApiError.wrapError(error);
    }
  },
  async putFile(
    fileId: number,
    request: ModifyGtfsRequestBody
  ): Promise<FileInfo> {
    try {
      const response = await apiManager.fileApi.updateFileFileFileIdPut(
        fileId,
        request
      );
      return response.data as FileInfo;
    } catch (error: any) {
      throw ApiError.wrapError(error);
    }
  },
  async downloadFile(fileId: number) {
    try {
      const response =
        await apiManager.downloadApi.downloadFileDownloadFileIdGet(fileId, {
          responseType: "blob",
        });
      const contentDisposition = response.headers["content-disposition"];
      let filename = "download.zip";

      if (contentDisposition) {
        const match = contentDisposition.match(
          /filename\*?=(?:UTF-8'')?([^;]+)/i
        );
        if (match && match[1]) {
          filename = decodeURIComponent(match[1].replace(/['"]/g, "")); // Remove quotes
        }
      }

      const href = URL.createObjectURL(response.data);

      const link = document.createElement("a");
      link.href = href;
      link.download = filename;
      document.body.appendChild(link);
      link.click();

      document.body.removeChild(link);
      URL.revokeObjectURL(href);
    } catch (error: any) {
      throw ApiError.wrapError(error);
    }
  },
  async postFile(
    fileType: FileType,
    roadClosureRequest:
      | RoadClosureRequest
      | ModifyOdMatrixRequest
      | SynthEdgesRequest
      | SynthTripsRequest
      | SynthStopsRequest
  ) {
    try {
      const response = await apiManager.fileApi.createFileFileFileTypePost(
        fileType,
        roadClosureRequest
      );
      return response.data as FileInfo;
    } catch (error: any) {
      throw ApiError.wrapError(error);
    }
  },
  async deleteFile(fileId: number) {
    try {
      await apiManager.fileApi.deleteFileFileFileIdDelete(fileId);
    } catch (error: any) {
      throw ApiError.wrapError(error);
    }
  },
};
