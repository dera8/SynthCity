import { apiManager } from "../api/apiManager";
import { ApiError } from "../api/errors/apiError";
import { FileInfo } from "../api/generated";

export const projectRepository = {
  async getProjectFiles(projectId: number): Promise<Array<FileInfo>> {
    try {
      const response =
        await apiManager.projectApi.retrieveProjectProjectProjectIdGet(
          projectId
        );
      return response.data.files;
    } catch (error: any) {
      throw ApiError.wrapError(error);
    }
  },
};
