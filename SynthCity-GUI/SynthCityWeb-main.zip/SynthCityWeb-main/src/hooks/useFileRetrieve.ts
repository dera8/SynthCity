import { useState, useCallback } from "react";
import { FullFileInfoFileData, FileInfo } from "../api/generated";
import { ApiError } from "../api/errors/apiError";
import { fileRepository } from "../repositories/fileRepository";

export const useFileRetrive = () => {
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [fileData, setFileData] = useState<FullFileInfoFileData | null>(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string>("idle");
  const [retrieveError, setRetrieveError] = useState<string | null>(null);

  const retrieveFile = useCallback(
    async (
      fileId: number,
      page?: number,
      pageSize?: number,
      query?: string
    ) => {
      setLoading(true);
      setStatus("loading");
      try {
        const retrievedFile = await fileRepository.getFile(
          fileId,
          page,
          pageSize,
          query
        );
        setFileInfo(retrievedFile.fileInfo);
        setFileData(retrievedFile.fileData);
        setStatus("successfull");
      } catch (err) {
        setStatus("error");
        if (err instanceof ApiError) {
          setRetrieveError(err.message);
        } else {
          setRetrieveError("Failed to retrieve the file.");
        }
      } finally {
        setLoading(false);
      }
    },
    []
  );
  const searchInFile = useCallback(async (fileId: number, query: string) => {
    setLoading(true);
    setStatus("loading");
    try {
      const retrievedFile = await fileRepository.getFile(
        fileId,
        undefined,
        undefined,
        query
      );
      setFileInfo(retrievedFile.fileInfo);
      setFileData(retrievedFile.fileData);
      setStatus("successfull");
    } catch (err) {
      setStatus("error");
      if (err instanceof ApiError) {
        setRetrieveError(err.message);
      } else {
        setRetrieveError("Failed to retrieve the file.");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  const resetFileRetrieve = useCallback(() => {
    setRetrieveError(null);
    setFileInfo(null);
    setLoading(false);
    setFileData(null);
  }, []);

  return {
    fileInfo,
    retrieveFile,
    searchInFile,
    loading,
    resetFileRetrieve,
    fileData,
    retrieveError,
    status,
  };
};
