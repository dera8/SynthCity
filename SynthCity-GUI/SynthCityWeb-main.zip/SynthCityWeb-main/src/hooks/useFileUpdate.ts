import { useState, useCallback } from "react";
import { FileInfo, ModifyGtfsRequestBody } from "../api/generated";
import { ApiError } from "../api/errors/apiError";
import { fileRepository } from "../repositories/fileRepository";

export const useFileUpdate = () => {
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [updateError, setUpdateError] = useState<string | null>(null);

  const updateFile = useCallback(
    async (fileId: number, request: ModifyGtfsRequestBody) => {
      setLoading(true);
      try {
        const updatedFile = await fileRepository.putFile(fileId, request);
        setFileInfo(updatedFile);
      } catch (err) {
        if (err instanceof ApiError) {
          setUpdateError(err.message);
        } else {
          setUpdateError("Failed to retrieve the file.");
        }
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const resetUpdateFile = useCallback(() => {
    setUpdateError(null);
    setFileInfo(null);
    setLoading(false);
  }, []);

  return {
    fileInfo,
    updateFile,
    loading,
    resetUpdateFile,
    updateError,
  };
};
