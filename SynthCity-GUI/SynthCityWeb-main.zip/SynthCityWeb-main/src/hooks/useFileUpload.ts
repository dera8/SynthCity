import { useState, useCallback, useEffect, useRef } from "react";
import { uploadRepository } from "../repositories/uploadRepository";
import { FullFileInfoFileData, FileInfo, FileType } from "../api/generated";
import { ApiError } from "../api/errors/apiError";
import { useFileRetrive } from "./useFileRetrieve";

interface useFileUploadOptions {
  withRetrieve?: boolean;
  withPeriodicStatusCheck?: boolean;
}

export const useFileUpload = (options: useFileUploadOptions) => {
  const { withRetrieve = false, withPeriodicStatusCheck = false } = options;
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [fileData, setFileData] = useState<FullFileInfoFileData | null>(null);
  const [loading, setLoading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [statusError, setStatusError] = useState<string | null>(null);
  const intervalRef = useRef<number>(0);
  const {
    fileData: retrievedFileData,
    fileInfo: retrievedFileInfo,
    retrieveFile,
    searchInFile,
    retrieveError,
    status,
  } = useFileRetrive();

  const uploadFile = useCallback(async (file: File, fileType: FileType) => {
    setLoading(true);
    setUploadError(null);
    try {
      const uploadedFile = await uploadRepository.uploadFile(file, fileType);
      setFileInfo(uploadedFile.fileInfo);
      setFileData(uploadedFile.fileData);
    } catch (err) {
      if (err instanceof ApiError) {
        setUploadError(err.message);
      } else {
        setUploadError("Failed to upload file.");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  const checkUploadStatus = useCallback(async (fileId: number) => {
    try {
      const uploadStatus = await uploadRepository.getUploadStatus(fileId);
      setFileInfo(uploadStatus);
    } catch (err) {
      if (err instanceof ApiError) {
        setStatusError(err.message);
      } else {
        setStatusError("Failed to check the upload status.");
      }
    }
  }, []);

  useEffect(() => {
    if (fileInfo && fileInfo.fileStatus) {
      console.log(fileInfo.fileStatus);

      if (
        fileInfo.fileStatus === "elaborating" &&
        intervalRef.current === 0 &&
        withPeriodicStatusCheck
      ) {
        intervalRef.current = setInterval(() => {
          console.log("Checking for status...");
          checkUploadStatus(fileInfo.fileId);
        }, 60 * 1000);
      }

      if (fileInfo.fileStatus === "completed") {
        if (intervalRef.current > 0) {
          console.log("Clearing interval");
          clearInterval(intervalRef.current);
          intervalRef.current = 0;
        }
        withRetrieve && status === "idle" && retrieveFile(fileInfo.fileId);
      }
      if (fileInfo.fileStatus === "failed") {
        setStatusError(
          "Error elaborating the file, check the backend logs for more info on the issue."
        );
        if (intervalRef.current > 0) {
          console.log("Clearing interval");
          clearInterval(intervalRef.current);
          intervalRef.current = 0;
        }
      }
    }
  }, [fileInfo, checkUploadStatus]);

  useEffect(() => {
    if (retrievedFileData) setFileData(retrievedFileData);
  }, [retrievedFileData]);

  useEffect(() => {
    if (retrievedFileInfo) setFileInfo(retrievedFileInfo);
  }, [retrievedFileInfo]);

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const resetFileUpload = useCallback(() => {
    setUploadError(null);
    setStatusError(null);
    setFileInfo(null);
    setLoading(false);
    setFileData(null);
    intervalRef.current = 0;
  }, []);

  return {
    fileInfo,
    uploadFile,
    loading,
    uploadError,
    resetFileUpload,
    fileData,
    statusError,
    retrieveError,
    retrieveFile,
    searchInFile,
    retrieveStatus: status,
  };
};
