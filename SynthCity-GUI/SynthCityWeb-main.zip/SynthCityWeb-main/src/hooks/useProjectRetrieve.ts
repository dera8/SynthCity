import { useState, useCallback } from "react";
import { FileInfo } from "../api/generated";
import { ApiError } from "../api/errors/apiError";
import { projectRepository } from "../repositories/projectRepository";

export const useProjectRetrieve = () => {
  const [files, setFiles] = useState<Array<FileInfo> | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const retrieveProjectFiles = useCallback(async (projectId: number) => {
    try {
      const retrievedFiles = await projectRepository.getProjectFiles(projectId);
      setFiles(retrievedFiles);
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
      } else {
        setError("Failed to retrieve the file.");
      }
    }
  }, []);

  const resetFileRetrieve = useCallback(() => {
    setError(null);
    setFiles(null);
    setLoading(false);
  }, []);

  return {
    files,
    retrieveProjectFiles,
    loading,
    resetFileRetrieve,
    error,
  };
};
