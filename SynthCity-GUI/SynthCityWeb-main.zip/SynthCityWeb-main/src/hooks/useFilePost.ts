import { useState, useCallback } from "react";
import {
  FileInfo,
  FileType,
  ModifyOdMatrixRequest,
  RoadClosureRequest,
  SynthEdgesRequest,
  SynthStopsRequest,
  SynthTripsRequest,
} from "../api/generated";
import { ApiError } from "../api/errors/apiError";
import { fileRepository } from "../repositories/fileRepository";

export const useFilePost = () => {
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [postError, setPostError] = useState<string | null>(null);

  const postRoadClosure = useCallback(
    async (fileType: FileType, roadClosureRequest: RoadClosureRequest) => {
      setLoading(true);
      try {
        const createdFile = await fileRepository.postFile(
          fileType,
          roadClosureRequest
        );
        setFileInfo(createdFile);
      } catch (err) {
        if (err instanceof ApiError) {
          setPostError(err.message);
        } else {
          setPostError("Failed to retrieve the file.");
        }
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const postModifyOdMatrix = useCallback(
    async (fileType: FileType, request: ModifyOdMatrixRequest) => {
      setLoading(true);
      try {
        const createdFile = await fileRepository.postFile(fileType, request);
        setFileInfo(createdFile);
      } catch (err) {
        if (err instanceof ApiError) {
          setPostError(err.message);
        } else {
          setPostError("Failed to retrieve the file.");
        }
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const postSynthEdges = useCallback(
    async (fileType: FileType, request: SynthEdgesRequest) => {
      setLoading(true);
      try {
        const createdFile = await fileRepository.postFile(fileType, request);
        setFileInfo(createdFile);
      } catch (err) {
        if (err instanceof ApiError) {
          setPostError(err.message);
        } else {
          setPostError("Failed to retrieve the file.");
        }
      } finally {
        setLoading(false);
      }
    },
    []
  );
  const postSynthStops = useCallback(
    async (fileType: FileType, request: SynthStopsRequest) => {
      setLoading(true);
      try {
        const createdFile = await fileRepository.postFile(fileType, request);
        setFileInfo(createdFile);
      } catch (err) {
        if (err instanceof ApiError) {
          setPostError(err.message);
        } else {
          setPostError("Failed to retrieve the file.");
        }
      } finally {
        setLoading(false);
      }
    },
    []
  );
  const postSynthTrips = useCallback(
    async (fileType: FileType, request: SynthTripsRequest) => {
      setLoading(true);
      try {
        const createdFile = await fileRepository.postFile(fileType, request);
        setFileInfo(createdFile);
      } catch (err) {
        if (err instanceof ApiError) {
          setPostError(err.message);
        } else {
          setPostError("Failed to retrieve the file.");
        }
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const resetPostFile = useCallback(() => {
    console.log("reset");
    setPostError(null);
    setLoading(false);
  }, []);

  return {
    postRoadClosure,
    postModifyOdMatrix,
    postSynthEdges,
    postSynthTrips,
    postSynthStops,
    loading,
    resetPostFile,
    postError,
    fileInfo,
  };
};
