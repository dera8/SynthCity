import { useState, useCallback } from "react";
import { ApiError } from "../api/errors/apiError";
import { fileRepository } from "../repositories/fileRepository";

export const useFileDelete = () => {
  const [loading, setLoading] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const deleteFile = useCallback(async (fileId: number) => {
    setLoading(true);
    try {
      await fileRepository.deleteFile(fileId);
    } catch (err) {
      if (err instanceof ApiError) {
        setDeleteError(err.message);
      } else {
        setDeleteError("Failed to retrieve the file.");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  const resetDeleteFile = useCallback(() => {
    setLoading(false);
    setDeleteError(null);
  }, []);

  return {
    deleteFile,
    loading,
    resetDeleteFile,
    deleteError,
  };
};
