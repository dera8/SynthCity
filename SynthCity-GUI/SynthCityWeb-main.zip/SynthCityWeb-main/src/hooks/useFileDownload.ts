import { useState, useCallback } from "react";
import { ApiError } from "../api/errors/apiError";
import { fileRepository } from "../repositories/fileRepository";

export const useFileDownload = () => {
  const [loading, setLoading] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  const downloadFile = useCallback(async (fileId: number) => {
    setLoading(true);
    try {
      await fileRepository.downloadFile(fileId);
    } catch (err) {
      if (err instanceof ApiError) {
        setDownloadError(err.message);
      } else {
        setDownloadError("Failed to download the file.");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  const resetFileDownload = useCallback(() => {
    setDownloadError(null);
  }, []);

  return {
    downloadFile,
    loading,
    resetFileDownload,
    downloadError,
  };
};
