import { FaTimes, FaUpload, FaDatabase } from "react-icons/fa";
import { FileInfo, FileType, FullFileInfoFileData } from "../api/generated";
import { useFileUpload } from "../hooks/useFileUpload";
import MessageOverlay from "./MessageOverlay";
import { useEffect, useRef, useState } from "react";
import { useProjectRetrieve } from "../hooks/useProjectRetrieve";
import { useFileRetrive } from "../hooks/useFileRetrieve";

interface FileSelectorProps {
  fileType: FileType;
  fileStatus?: string;
  label: string;
  projectId: number;
  fileInfo: FileInfo | null;
  withRetrieve?: boolean;
  setFileInfo?: (info: FileInfo | null) => void;
  setFileData?: (data: FullFileInfoFileData | null) => void;
  loadingMessage?: string;
  retrievingMessage?: string;
  onReset?: () => void;
}

const FileSelector = ({
  fileType,
  fileStatus = "",
  projectId,
  setFileData,
  setFileInfo,
  loadingMessage = "Uploading File",
  retrievingMessage = "Retrieving File",
  label,
  fileInfo,
  withRetrieve = false,
  onReset,
}: FileSelectorProps) => {
  const upload = useFileUpload({});
  const retrieve = useFileRetrive();
  const { files, retrieveProjectFiles } = useProjectRetrieve();
  const [showDbFiles, setShowDbFiles] = useState(false);
  const [showNotReadyMessage, setShowNotReadyMessage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    retrieveProjectFiles(projectId);
  }, [projectId]);

  useEffect(() => {
    if (upload.fileInfo) setFileInfo?.(upload.fileInfo);
    if (upload.fileData) setFileData?.(upload.fileData);
    setShowDbFiles(false);
  }, [upload.fileInfo, upload.fileData]);

  const handleFileUpload = (files: FileList | null) => {
    const file = files?.[0];
    if (file) {
      upload.uploadFile(file, fileType);
    } else {
      alert("No file chosen!");
    }
  };

  const handleReset = () => {
    onReset && onReset();
    setFileInfo?.(null);
    setFileData?.(null);
    upload.resetFileUpload();
    retrieve.resetFileRetrieve();
    setShowDbFiles(false);
  };

  const handleDbFileSelect = (file: FileInfo) => {
    if (fileStatus !== "" && fileStatus !== file.fileStatus) {
      setShowNotReadyMessage(true);
      return;
    }
    setFileInfo?.(file);
    if (withRetrieve) {
      retrieve.retrieveFile(file.fileId);
    }
    setShowDbFiles(false);
  };

  const triggerFileDialog = () => {
    fileInputRef.current?.click();
  };

  const handleDbButtonClick = () => {
    retrieveProjectFiles(projectId);
    setShowDbFiles(true);
  };

  const handleCloseNotReadyMessage = () => {
    setShowNotReadyMessage(false);
    retrieveProjectFiles(projectId);
  };
  useEffect(() => {
    if (showDbFiles) {
      retrieveProjectFiles(projectId);
    }
  }, [showDbFiles]);

  useEffect(() => {
    if (retrieve.fileData && setFileData && fileInfo) {
      console.log("here");
      setFileData(retrieve.fileData);
    }
  }, [retrieve]);

  return (
    <div className="space-y-4">
      {upload.loading && (
        <MessageOverlay type="loader" message={loadingMessage} />
      )}
      {showNotReadyMessage && (
        <MessageOverlay
          type="info"
          message={`The selected file is not in the '${fileStatus}' state, try again later.`}
          onDismiss={handleCloseNotReadyMessage}
        />
      )}
      {withRetrieve && retrieve.status == "loading" && (
        <MessageOverlay type="loader" message={retrievingMessage} />
      )}
      <div className="flex items-center space-x-4">
        <span className="font-semibold whitespace-nowrap">{label}</span>
        {!fileInfo && (
          <>
            <button
              type="button"
              onClick={triggerFileDialog}
              className="flex items-center px-3 py-1 rounded border text-sm bg-green-600 text-white hover:bg-green-500"
            >
              <FaUpload className="mr-2" />
              Upload
            </button>

            <button
              type="button"
              onClick={handleDbButtonClick}
              className="flex items-center px-3 py-1 rounded border text-sm bg-green-100 text-green-700 hover:bg-green-200"
            >
              <FaDatabase className="mr-2" />
              From Project
            </button>

            <input
              type="file"
              className="hidden"
              ref={fileInputRef}
              onChange={(e) => handleFileUpload(e.target.files)}
            />
          </>
        )}
      </div>

      {fileInfo && (
        <div className="flex items-center justify-between bg-green-50 border border-green-300 rounded px-4 py-2 mt-2 w-3/4">
          <p className="text-green-600 flex-1 truncate">
            File selected: {fileInfo.fileName}
          </p>
          <button
            onClick={handleReset}
            className="text-red-500 hover:text-red-700 ml-4"
            aria-label="Remove file"
          >
            <FaTimes />
          </button>
        </div>
      )}

      {showDbFiles && (
        <div className="space-y-2 border border-green-200 rounded p-4 max-h-60 overflow-y-auto">
          {retrieve.status === "loading" && <p>loading</p>}
          {retrieve.status !== "loading" && files?.length ? (
            files
              .filter((file) => file.fileType === fileType)
              .map((file) => (
                <div
                  key={file.fileId}
                  className={`px-3 py-1 rounded flex items-center ${
                    fileStatus === "" || fileStatus === file.fileStatus
                      ? "cursor-pointer hover:bg-green-100 "
                      : "bg-gray-100"
                  }`}
                  onClick={() => handleDbFileSelect(file)}
                >
                  <span className="text-green-700 truncate px-1">
                    {file.fileName}{" "}
                  </span>
                  {fileStatus !== "" && (
                    <span className="truncate px-1"> - </span>
                  )}
                  {fileStatus !== "" && (
                    <span className="italic text-green-600 truncate px-1">
                      {file.fileStatus}
                    </span>
                  )}
                </div>
              ))
          ) : (
            <p className="text-gray-500 text-sm">No files found in project.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default FileSelector;
