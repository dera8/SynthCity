import React, { useState } from "react";

interface FilteredMultiSelectProps<T> {
  options: T[];
  onOptionClick?: (option: T) => void;
  validationError: string | null;
  selectedItems: T[];
  setSelectedItems: React.Dispatch<React.SetStateAction<T[]>>;
  getOptionLabel: (option: T) => string;
}

const FilteredMultiSelect = <T,>(props: FilteredMultiSelectProps<T>) => {
  const {
    options,
    onOptionClick,
    selectedItems,
    setSelectedItems,
    getOptionLabel,
    validationError,
  } = props;
  const [filter, setFilter] = useState("");

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilter(e.target.value);
  };

  const handleOptionClick = (option: T) => {
    setSelectedItems((prevSelected) =>
      prevSelected.includes(option)
        ? prevSelected.filter((item) => item !== option)
        : [...prevSelected, option]
    );
    onOptionClick && onOptionClick(option);
    setFilter("");
  };

  const filteredOptions = options.filter((option) =>
    getOptionLabel(option).toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="w-full">
      <input
        type="text"
        value={filter}
        onChange={handleFilterChange}
        placeholder="Filter options..."
        className="w-full mb-2 border rounded px-4 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500"
      />
      <div
        className={`border rounded shadow-sm p-2 overflow-auto min-h-40 max-h-60 ${
          validationError ? "border-red-500" : ""
        }`}
      >
        {filteredOptions.length === 0 && (
          <p className="text-gray-500">No matches found.</p>
        )}
        <div className="flex flex-col">
          {filteredOptions.map((option, index) => (
            <div
              key={index}
              onClick={() => handleOptionClick(option)}
              className={`py-2 px-3 rounded cursor-pointer ${
                selectedItems.includes(option)
                  ? "bg-green-500 text-white"
                  : "hover:bg-green-100"
              }`}
            >
              {getOptionLabel(option)}
            </div>
          ))}
        </div>
      </div>
      {validationError && (
        <p className="text-red-500 text-sm mt-1">{validationError}</p>
      )}
    </div>
  );
};

export default FilteredMultiSelect;
