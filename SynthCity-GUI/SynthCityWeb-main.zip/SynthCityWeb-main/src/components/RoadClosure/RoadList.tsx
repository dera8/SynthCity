import { useState } from "react";
import {
  FaEdit,
  FaTrash,
  FaCheck,
  FaTimes,
  FaMapMarkerAlt,
} from "react-icons/fa";
import { RoadClosure } from "../../api/generated";

interface ListProps {
  items: RoadClosure[];
  onUpdate: React.Dispatch<React.SetStateAction<RoadClosure[]>>;
}

export default function RoadList({ items, onUpdate }: ListProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tempStart, setTempStart] = useState("0");
  const [tempFinish, setTempFinish] = useState("23");

  const handleEdit = (item: RoadClosure) => {
    setEditingId(item.name);
    setTempStart(item.startTime);
    setTempFinish(item.endTime);
  };

  const handleSave = (id: string) => {
    const updatedItems = items.map((item) =>
      item.name === id
        ? { ...item, startTime: tempStart, endTime: tempFinish }
        : item
    );
    onUpdate(updatedItems);
    setEditingId(null);
  };

  const handleCancel = () => {
    setEditingId(null);
  };

  const handleDelete = (id: string) => {
    onUpdate(items.filter((item) => item.name !== id));
  };

  return (
    <div className="flex flex-col gap-2 h-full">
      {items.map((item) => (
        <div
          key={item.name}
          className="p-4 bg-white shadow-md rounded-lg flex flex-col gap-2 border-l-4 border-green-500"
        >
          <div className="text-lg font-semibold text-green-700">
            {item.name}
          </div>
          <div className="flex items-center gap-2 text-gray-800">
            {editingId === item.name ? (
              <>
                <input
                  type="number"
                  max={23}
                  min={0}
                  step={1}
                  value={tempStart}
                  onChange={(e) => setTempStart(e.target.value)}
                  className="border p-1 rounded"
                />
                -
                <input
                  type="number"
                  max={23}
                  min={0}
                  step={1}
                  value={tempFinish}
                  onChange={(e) => setTempFinish(e.target.value)}
                  className="border p-1 rounded"
                />
              </>
            ) : (
              <span className="text-sm text-green-600">
                {item.startTime} - {item.endTime}
              </span>
            )}
          </div>
          <div className="flex gap-4 text-green-700">
            <FaMapMarkerAlt className="cursor-pointer hover:text-green-500" />
            {editingId === item.name ? (
              <>
                <FaCheck
                  className="cursor-pointer hover:text-green-500"
                  onClick={() => handleSave(item.name)}
                />
                <FaTimes
                  className="cursor-pointer hover:text-red-500"
                  onClick={handleCancel}
                />
              </>
            ) : (
              <FaEdit
                className="cursor-pointer hover:text-green-500"
                onClick={() => handleEdit(item)}
              />
            )}
            <FaTrash
              className="cursor-pointer hover:text-red-500"
              onClick={() => handleDelete(item.name)}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
