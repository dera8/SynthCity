import { useCallback, useEffect, useMemo, useState } from "react";
import { GroupedRoad, NetworkInfo } from "../../api/generated";
import Autocomplete, { AutocompleteOption } from "../Autocomplete";
import { useFileRetrive } from "../../hooks/useFileRetrieve";

interface RoadAutocompleteProps {
  inputValue: string;
  onInputChange: (value: string) => void;
  roads: GroupedRoad[];
  addRoads: (roads: GroupedRoad[]) => void;
  resetRoads: () => void;
  selectedFile: number;
}

const RoadAutocomplete = (props: RoadAutocompleteProps) => {
  const [page, setPage] = useState<number>(1);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const {
    roads,
    inputValue,
    onInputChange,
    addRoads,
    selectedFile,
    resetRoads,
  } = props;
  const [lastQuery, setLastQuery] = useState("");

  const {
    retrieveFile: search,
    fileData: retrieveData,
    loading: retrieveLoading,
  } = useFileRetrive();
  const filteredOptions = useMemo(() => {
    if (inputValue.trim().length > 0)
      if (roads.length > 0)
        return roads
          .filter((road) =>
            road.name
              .toLocaleLowerCase()
              .includes(inputValue.toLocaleLowerCase())
          )
          .map(
            (road, index) =>
              ({ id: index, label: road.name } as AutocompleteOption)
          );
    return roads.map(
      (road, index) => ({ id: index, label: road.name } as AutocompleteOption)
    );
  }, [inputValue, roads]);

  const handleLoadMore = useCallback(() => {
    console.log(lastQuery.toLocaleLowerCase());
    console.log(inputValue.toLocaleLowerCase());
    const query = inputValue.length > 0 ? inputValue : undefined;
    if (lastQuery.toLocaleLowerCase() === inputValue.toLocaleLowerCase()) {
      let nextPage = page + 1;
      setPage(nextPage);
      search(selectedFile, nextPage, undefined, query);
    } else {
      setLastQuery(inputValue);
      let nextPage = 1;
      resetRoads();
      setPage(nextPage);
      search(selectedFile, nextPage, undefined, query);
    }
  }, [page, lastQuery, inputValue]);

  useEffect(() => {
    console.log("inputValue ", inputValue);
  }, [inputValue]);
  useEffect(() => {
    console.log("lastQuery ", lastQuery);
  }, [lastQuery]);

  useEffect(() => {
    if (retrieveData) {
      const list = (retrieveData as NetworkInfo).roadList?.roads ?? [];
      const maxPage =
        (retrieveData as NetworkInfo).roadList?.paginator.totalPages ?? 0;
      if (maxPage <= page) setHasMore(false);
      addRoads(list);
    }
  }, [retrieveData, page]);
  return (
    <Autocomplete
      inputValue={inputValue}
      onInputChange={onInputChange}
      options={filteredOptions}
      hasMore={hasMore}
      onLoadMore={handleLoadMore}
      onOptionSelect={(option) => onInputChange(option.label)}
      loading={retrieveLoading}
    />
  );
};

export default RoadAutocomplete;
