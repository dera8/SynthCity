import { LatLngExpression } from "leaflet";
import { Polyline } from "react-leaflet";
import MapView from "../Leaflet/MapView";
import { GroupedRoad } from "../../api/generated";
import { coordinatesArrayParser } from "../../api/parsers/networkParsers";

export interface StreetData {
  edgeId: string;
  streetName: string;
  path: LatLngExpression[];
}

interface RoadMapProps {
  mapCenter: LatLngExpression;
  streets: GroupedRoad[];
  selectedStreet: string;
}

const RoadMap = (props: RoadMapProps) => {
  const { mapCenter, streets, selectedStreet } = props;

  return (
    <MapView center={mapCenter}>
      {streets
        .filter((street) => street.name === selectedStreet)
        .map((groupedRoad) =>
          groupedRoad.edges.map((edge) => (
            <Polyline
              key={edge.edgeId}
              positions={coordinatesArrayParser(edge.path)}
              color="green"
              weight={5}
            />
          ))
        )}
    </MapView>
  );
};

export default RoadMap;
