import { useEffect } from "react";
import { MapContainer, TileLayer, useMap, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { LatLngExpression } from "leaflet";

interface MapViewProps {
  center: LatLngExpression;
  children: React.ReactNode;
}

function ChangeMapCenter({ center }: { center: LatLngExpression }) {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.setView(center, map.getZoom());
    }
  }, [center, map]);
  return null;
}

function MapLocator() {
  const map = useMapEvents({
    click: (event) => {
      console.log(event.latlng);
    },
  });
  return null;
}

const MapView = (props: MapViewProps) => {
  const { center, children } = props;
  return (
    <MapContainer center={center} zoom={12} scrollWheelZoom={false}>
      <TileLayer
        attribution='&copy; <a href="https://osm.org/copyright" target=_blank>OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <ChangeMapCenter center={center} />
      <MapLocator />
      {children}
    </MapContainer>
  );
};

export default MapView;
