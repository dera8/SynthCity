import { useEffect, useRef, useState } from "react";
import { FaSearch, FaTimes, FaSpinner } from "react-icons/fa";

export interface AutocompleteOption {
  id: number;
  label: string;
}

interface AutocompleteProps {
  inputValue: string;
  onInputChange: (value: string) => void;
  onOptionSelect: (option: AutocompleteOption) => void;
  options: AutocompleteOption[];
  hasMore: boolean;
  onLoadMore: () => void;
  loading?: boolean;
}

const Autocomplete = ({
  inputValue,
  onInputChange,
  onOptionSelect,
  options,
  hasMore,
  onLoadMore,
  loading = false,
}: AutocompleteProps) => {
  const [highlightedIndex, setHighlightedIndex] = useState(0);
  const [listOpen, setListOpen] = useState(false);
  const [justSearched, setJustSearched] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    itemRefs.current = [];
    setHighlightedIndex(0);
  }, [options, listOpen]);

  useEffect(() => {
    const el = itemRefs.current[highlightedIndex];
    if (el) {
      el.scrollIntoView({ block: "nearest" });
    }
  }, [highlightedIndex]);

  const clearInput = () => {
    onInputChange("");
    setListOpen(false);
    inputRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const maxIndex = options.length;

    if (!listOpen && e.key !== "Tab" && e.key !== "Shift") {
      setListOpen(true);
    }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setHighlightedIndex((prev) => Math.min(prev + 1, maxIndex));
    }

    if (e.key === "ArrowUp") {
      e.preventDefault();
      setHighlightedIndex((prev) => Math.max(prev - 1, 0));
    }

    if (e.key === "Enter") {
      e.preventDefault();
      if (highlightedIndex === options.length && hasMore) {
        onLoadMore();
      } else if (options[highlightedIndex]) {
        onOptionSelect(options[highlightedIndex]);
        setListOpen(false);
      } else if (options.length === 0 && !justSearched) {
        console.log("Search triggered:", inputValue);
        setJustSearched(true);
        setListOpen(false);
      } else {
        setListOpen(true);
      }
    }

    if (e.key === "Tab") {
      if (listOpen && options[highlightedIndex]) {
        onOptionSelect(options[highlightedIndex]);
        setListOpen(false);
      } else if (options.length === 0 && !justSearched) {
        console.log("Search triggered (tab):", inputValue);
        setJustSearched(true);
      }
    }

    if (e.key === "Escape") {
      setListOpen(false);
    }
  };

  const handleBlur = () => {
    setTimeout(() => setListOpen(false), 100);
  };

  const showSearchIcon = inputValue?.replace(/\s/g, "").length >= 4;

  return (
    <div className="w-full max-w-md relative">
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          className="w-full border border-gray-300 rounded px-10 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
          placeholder="Start typing..."
          value={inputValue}
          onChange={(e) => {
            onInputChange(e.target.value);
            setJustSearched(false);
            setListOpen(true);
          }}
          onKeyDown={handleKeyDown}
          onBlur={handleBlur}
          onFocus={() => setListOpen(true)}
        />

        {showSearchIcon && !loading && (
          <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-green-400" />
        )}
        {loading && (
          <FaSpinner className="absolute left-3 top-1/2 text-green-400 animate-spin" />
        )}
        {inputValue && (
          <FaTimes
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-green-500 cursor-pointer hover:text-red-600"
            onClick={clearInput}
          />
        )}
      </div>

      {listOpen && true && (
        <div className="absolute w-full border border-t-0 border-gray-300 rounded-b shadow-md mt-1 max-h-60 overflow-auto z-10 bg-white">
          {loading && (
            <div className="px-4 py-2 text-gray-500 italic">Loading...</div>
          )}

          {!loading && options.length === 0 && (
            <div className="px-4 py-2 text-gray-500">No results found.</div>
          )}

          {!loading &&
            options.map((option, idx) => (
              <div
                key={option.id}
                ref={(el) => (itemRefs.current[idx] = el)}
                className={`px-4 py-2 cursor-pointer ${
                  idx === highlightedIndex
                    ? "bg-green-100 font-medium"
                    : "hover:bg-green-50"
                }`}
                onMouseEnter={() => setHighlightedIndex(idx)}
                onClick={() => {
                  onOptionSelect(option);
                  setListOpen(false);
                }}
              >
                {option.label}
              </div>
            ))}

          {!loading && (hasMore || options.length === 0) && (
            <div
              ref={(el) => (itemRefs.current[options.length] = el)}
              className={`px-4 py-2 text-green-600 cursor-pointer bg-gray-50 ${
                highlightedIndex === options.length
                  ? "bg-green-100 font-medium"
                  : "hover:bg-green-100"
              }`}
              onMouseEnter={() => setHighlightedIndex(options.length)}
              onClick={onLoadMore}
            >
              {options.length === 0 ? "Search" : "Load more"}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Autocomplete;
