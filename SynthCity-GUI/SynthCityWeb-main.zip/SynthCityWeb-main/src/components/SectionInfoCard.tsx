interface SectionInfoCardProps {
  title: string;
  desc: string;
  link?: string;
}
const SectionInfoCard = (props: SectionInfoCardProps) => {
  const { title, desc, link } = props;
  return (
    <div className="w-64 h-64 bg-green-50 border border-green-200 rounded-2xl shadow-sm flex flex-col p-4">
      <h4 className="text-green-700 font-semibold text-lg">{title}</h4>
      <p className="text-gray-700 text-sm pt-10">{desc}</p>
      {link !== undefined && (
        <div className="mt-auto flex justify-end">
          <a
            className="text-green-700 text-sm hover:underline cursor-pointer"
            href={`${link}`}
          >
            try it out →
          </a>
        </div>
      )}
    </div>
  );
};

export default SectionInfoCard;
