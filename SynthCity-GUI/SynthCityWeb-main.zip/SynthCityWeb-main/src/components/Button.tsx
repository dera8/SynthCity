interface ButtonProps {
  label?: string;
  enabled?: boolean;
  icon?: JSX.Element;
  className?: string;
  onClick?: () => void;
  containerClassName?: string;
}
const Button = (props: ButtonProps) => {
  const {
    label,
    enabled = true,
    icon,
    className = "",
    onClick,
    containerClassName,
  } = props;
  return (
    <div className={containerClassName}>
      <button
        type="button"
        className={`bg-green-600 text-white px-4 py-2 rounded shadow hover:bg-green-500 disabled:bg-gray-300 disabled:cursor-not-allowed ${className}`}
        disabled={!enabled}
        onClick={onClick}
      >
        {icon} {label}
      </button>
    </div>
  );
};

export default Button;
