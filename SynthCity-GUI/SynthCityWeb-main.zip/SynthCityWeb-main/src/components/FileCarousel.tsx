import FileCard from "./FileCard";
import { FileInfo } from "../api/generated";

interface FileCarouselProps {
  title: string;
  files: FileInfo[];
  globalFilter: string;
  expandedCardId: number | null;
  setExpandedCardId: (id: number | null) => void;
  onDownload: (fileId: number) => void;
  onDelete: (fileId: number) => void;
}

const FileCarousel = (props: FileCarouselProps) => {
  const {
    title,
    files,
    globalFilter,
    expandedCardId,
    setExpandedCardId,
    onDownload,
    onDelete,
  } = props;

  const filteredFiles = files.filter((file) =>
    file.fileName.toLowerCase().includes(globalFilter.toLowerCase())
  );

  return (
    <div className="mb-10 " style={{ maxWidth: 1480 }}>
      <h2 className="text-xl font-bold mb-2">{title}</h2>

      <div className="relative">
        <div className="overflow-x-auto scroll-smooth snap-x snap-mandatory px-4 border rounded-xl shadow-inner">
          <div className="flex flex-nowrap space-x-4 px-2">
            {filteredFiles.length > 0 ? (
              filteredFiles.map((file) => (
                <div
                  key={file.fileId}
                  className=" w-48 flex-shrink-0 snap-start my-8 px-4"
                >
                  <FileCard
                    file={file}
                    expanded={expandedCardId === file.fileId}
                    setExpandedCardId={setExpandedCardId}
                    onDelete={onDelete}
                    onDownload={onDownload}
                  />
                </div>
              ))
            ) : (
              <div className="w-full flex justify-center items-center h-48">
                <p className="text-gray-500 italic">No files found</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FileCarousel;
