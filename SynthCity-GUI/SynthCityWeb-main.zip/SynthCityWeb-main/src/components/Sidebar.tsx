import { Link, useLocation } from "react-router-dom";

const Sidebar = () => {
  const location = useLocation();

  const subItemsDG = [
    { name: "Stops Generation", path: "/data-generation/stops" },
    { name: "Edges Generation", path: "/data-generation/edges" },
    { name: "Trips Generation", path: "/data-generation/trips" },
  ];

  const subItemsGTFS = [
    { name: "Modify GTFS Routes", path: "/modify-gtfs/routes" },
    { name: "Delete GTFS Stops", path: "/modify-gtfs/stops" },
  ];

  const menuItems = [
    { name: "Home", path: "/" },
    { name: "Dashboard", path: "/dashboard" },
    { name: "Modify GTFS", path: "/modify-gtfs", subItems: subItemsGTFS },
    { name: "Close Roads", path: "/close-roads" },
    { name: "Modify OD Matricies", path: "/modify-matrices" },
    {
      name: "Synthetic Data Generation",
      path: "/data-generation",
      subItems: subItemsDG,
    },
  ];

  return (
    <div className="w-1/8 bg-white border-r border-gray-300">
      <ul className="space-y-2 p-4">
        {menuItems.map((item) => (
          <li key={item.path} className="relative">
            <Link
              to={item.path}
              className={`block p-2 rounded ${
                location.pathname.startsWith(item.path) && item.path !== "/"
                  ? "bg-green-100"
                  : "hover:bg-green-100"
              }`}
            >
              {item.name}
            </Link>

            {item.subItems && location.pathname.startsWith(item.path) && (
              <ul className="mt-2 ml-4 space-y-1 border-t border-gray-300 pt-2">
                {item.subItems.map((subItem) => (
                  <li key={subItem.path}>
                    <Link
                      to={subItem.path}
                      className={`block p-2 rounded ${
                        location.pathname === subItem.path
                          ? "bg-green-200"
                          : "hover:bg-green-200"
                      }`}
                    >
                      {subItem.name}
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Sidebar;
