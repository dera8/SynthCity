import { useState } from "react";
import {
  FaFileCsv,
  FaFileArchive,
  FaFileCode,
  FaDownload,
  FaTrash,
  FaFile,
} from "react-icons/fa";
import { FileInfo, FileType } from "../api/generated";

interface FileCardProps {
  file: FileInfo;
  expanded: boolean;
  setExpandedCardId: (id: number | null) => void;
  onDownload: (fileId: number) => void;
  onDelete: (fileId: number) => void;
}

const FileCard = (props: FileCardProps) => {
  const { file, expanded, setExpandedCardId, onDelete, onDownload } = props;
  const [confirmDelete, setConfirmDelete] = useState(false);

  const getIcon = () => {
    switch (file.fileType) {
      case FileType.Gtfs:
        return <FaFileArchive className="text-green-600 text-4xl" />;
      case FileType.SynthEdges:
      case FileType.SynthTrips:
      case FileType.SynthStops:
      case FileType.StopData:
        return <FaFileCsv className="text-green-600 text-4xl" />;
      case FileType.Network:
      case FileType.RoadClosure:
      case FileType.TripData:
      case FileType.Taz:
      case FileType.Odmatrix:
      case FileType.StopSim:
      case FileType.EdgeData:
        return <FaFileCode className="text-green-600 text-4xl" />;
      default:
        return <FaFile className="text-green-600 text-4xl" />;
    }
  };

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDelete(true);
  };

  const handleCancelDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDelete(false);
  };

  const handleCardClick = () => {
    setExpandedCardId(expanded ? null : file.fileId);
    setConfirmDelete(false);
  };

  return (
    <div
      className="w-48 h-48 perspective cursor-pointer mx-2"
      onClick={handleCardClick}
    >
      <div
        className={`relative w-full h-full duration-500 rounded-2xl shadow border bg-white`}
      >
        <div className="absolute w-full h-full flex flex-col items-center justify-center p-4 space-y-2">
          {getIcon()}
          <p className="text-center text-sm text-gray-800 truncate w-full">
            {file.fileName}
          </p>
        </div>

        {expanded && (
          <div className="absolute w-full h-full rotate-y-180 bg-white rounded-2xl p-4 text-xs text-gray-700 flex flex-col justify-between">
            <div className="space-y-1">
              <p>
                <strong>FileName:</strong> {file.fileName}
              </p>
              <p>
                <strong>Path:</strong> {file.filePath}
              </p>
              <p>
                <strong>Status:</strong> {file.fileStatus}
              </p>
            </div>
            <div className="pt-2">
              {!confirmDelete ? (
                <div className="flex justify-end space-x-2">
                  <button
                    type="button"
                    className="text-green-600 hover:text-green-800"
                    title="Download"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDownload(file.fileId);
                    }}
                  >
                    <FaDownload />
                  </button>
                  <button
                    type="button"
                    className="text-red-500 hover:text-red-700"
                    onClick={handleDeleteClick}
                    title="Delete"
                  >
                    <FaTrash />
                  </button>
                </div>
              ) : (
                <div className="flex justify-between items-center">
                  <p className="text-sm">Are you sure?</p>
                  <div className="space-x-2">
                    <button
                      className="text-sm text-red-600 hover:underline"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDelete(file.fileId);
                      }}
                    >
                      Yes
                    </button>
                    <button
                      className="text-sm text-gray-600 hover:underline"
                      onClick={handleCancelDelete}
                    >
                      No
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default FileCard;
