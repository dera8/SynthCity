import React, { useEffect, useState } from "react";

interface DatePickerProps {
  label?: string;
  value: string;
  onDateSelected: (date: string) => void;
}

const DatePicker = (props: DatePickerProps) => {
  const { label = "Select Date", value, onDateSelected } = props;
  const [selectedDate, setSelectedDate] = useState<string | undefined>(
    undefined
  );

  useEffect(() => {
    if (value !== undefined && value !== selectedDate) {
      setSelectedDate(value);
    }
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newDate = e.target.value;
    setSelectedDate(newDate);
    onDateSelected?.(newDate);
  };

  return (
    <div className="inline-block">
      <label className="flex items-center space-x-2">
        <span className="font-semibold">{label}</span>
        <input
          type="date"
          value={selectedDate}
          onChange={handleChange}
          className="border border-green-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500 text-gray-700"
        />
      </label>
    </div>
  );
};

export default DatePicker;
