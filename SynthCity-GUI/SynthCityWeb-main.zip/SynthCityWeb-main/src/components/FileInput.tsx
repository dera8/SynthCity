import React, { useState } from "react";
import { FaInfoCircle } from "react-icons/fa";

export interface FileInputProps {
  title: string;
  description?: string;
  buttonLabel?: string;
  placeholder?: string;
  maxFiles?: number;
  onFileChange?: (files: FileList | null) => void;
}

const FileInput = ({
  title,
  description,
  buttonLabel = "Browse",
  placeholder = "No file selected",
  maxFiles,
  onFileChange,
}: FileInputProps) => {
  const [selectedFile, setSelectedFile] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && maxFiles && files.length > maxFiles) {
      alert(`You can only select up to ${maxFiles} file(s).`);
      e.target.value = "";
      return;
    }
    if (files && files.length > 0) {
      setSelectedFile(files[0].name);
    } else {
      setSelectedFile(null);
    }
    if (onFileChange) {
      onFileChange(files);
    }
  };

  return (
    <div className="flex items-center space-x-4">
      <div className="flex items-center space-x-2">
        <span className="font-semibold">{title}</span>
        {description && (
          <div className="relative group">
            <FaInfoCircle className="cursor-pointer text-green-600 hover:text-green-500 transition" />
            <div className="absolute left-0 mt-2 hidden group-hover:block bg-green-200 text-sm rounded px-3 py-2 shadow-lg whitespace-pre-line min-w-64">
              {description}
            </div>
          </div>
        )}
      </div>

      <span className="flex-1 text-green-600 truncate">
        {selectedFile || placeholder}
      </span>
      <label className="bg-green-600 text-white px-4 py-2 rounded cursor-pointer hover:bg-green-500 transition">
        {buttonLabel}
        <input type="file" className="hidden" onChange={handleFileChange} />
      </label>
    </div>
  );
};

export default FileInput;
