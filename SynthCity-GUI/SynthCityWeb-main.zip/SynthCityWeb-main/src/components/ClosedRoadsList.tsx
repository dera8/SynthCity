import { useState } from "react";
import {
  FaPlus,
  FaEdit,
  FaTrash,
  FaCheck,
  FaTimes,
  FaMapMarkerAlt,
} from "react-icons/fa";
import Button from "./Button";

interface Road {
  id: number;
  name: string;
  startTime: string;
  endTime: string;
  isEditing?: boolean;
}

interface ClosedRoadListProps {
  enabled?: boolean;
}
const ClosedRoadsList = (props: ClosedRoadListProps) => {
  const { enabled = true } = props;
  const [roads, setRoads] = useState<Road[]>([]);
  const [newRoad, setNewRoad] = useState<Omit<Road, "id" | "isEditing"> | null>(
    null
  );

  const handleAddRoad = () => {
    setNewRoad({ name: "", startTime: "", endTime: "" });
  };

  const handleSaveNewRoad = () => {
    if (newRoad?.name && newRoad.startTime && newRoad.endTime) {
      setRoads([...roads, { id: Date.now(), ...newRoad }]);
      setNewRoad(null);
    }
  };

  const handleCancelNewRoad = () => {
    setNewRoad(null);
  };

  const handleEditRoad = (id: number) => {
    setRoads((prev) =>
      prev.map((road) =>
        road.id === id
          ? { ...road, isEditing: true }
          : { ...road, isEditing: false }
      )
    );
  };

  const handleSaveEditRoad = (
    id: number,
    updatedRoad: Omit<Road, "id" | "isEditing">
  ) => {
    setRoads((prev) =>
      prev.map((road) =>
        road.id === id ? { ...road, ...updatedRoad, isEditing: false } : road
      )
    );
  };

  const handleCancelEditRoad = (id: number) => {
    setRoads((prev) =>
      prev.map((road) =>
        road.id === id ? { ...road, isEditing: false } : road
      )
    );
  };

  const handleDeleteRoad = (id: number) => {
    setRoads((prev) => prev.filter((road) => road.id !== id));
  };

  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-semibold">Closed Roads</h1>
        <Button label="Add Road" icon={<FaPlus className="mr-2" />} enabled={enabled} className="flex items-center" onClick={handleAddRoad}/>
      </div>

      <div className="space-y-4">
        {roads.map((road) =>
          road.isEditing ? (
            <div key={road.id} className="flex items-center space-x-4">
              <input
                type="text"
                placeholder="Name"
                defaultValue={road.name}
                className="border-gray-300 rounded shadow-sm px-2 py-1 w-1/4"
                onChange={(e) =>
                  setRoads((prev) =>
                    prev.map((r) =>
                      r.id === road.id ? { ...r, name: e.target.value } : r
                    )
                  )
                }
              />
              <input
                type="text"
                placeholder="Start Time"
                defaultValue={road.startTime}
                className="border-gray-300 rounded shadow-sm px-2 py-1 w-1/4"
                onChange={(e) =>
                  setRoads((prev) =>
                    prev.map((r) =>
                      r.id === road.id ? { ...r, startTime: e.target.value } : r
                    )
                  )
                }
              />
              <input
                type="text"
                placeholder="End Time"
                defaultValue={road.endTime}
                className="border-gray-300 rounded shadow-sm px-2 py-1 w-1/4"
                onChange={(e) =>
                  setRoads((prev) =>
                    prev.map((r) =>
                      r.id === road.id ? { ...r, endTime: e.target.value } : r
                    )
                  )
                }
              />
              <button
                onClick={() => handleSaveEditRoad(road.id, road)}
                className="bg-green-600 text-white px-2 py-1 rounded hover:bg-green-500"
              >
                <FaCheck />
              </button>
              <button
                onClick={() => handleCancelEditRoad(road.id)}
                className="bg-red-600 text-white px-2 py-1 rounded hover:bg-red-500"
              >
                <FaTimes />
              </button>
            </div>
          ) : (
            <div
              key={road.id}
              className="flex items-center justify-between border p-4 rounded bg-white shadow-sm"
            >
              <div>
                <p className="font-medium">{road.name}</p>
                <p className="text-gray-500 text-sm">
                  {road.startTime} - {road.endTime}
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => handleEditRoad(road.id)}
                  className="text-blue-500 hover:text-blue-400"
                >
                  <FaEdit />
                </button>
                <button
                  onClick={() => handleDeleteRoad(road.id)}
                  className="text-red-500 hover:text-red-400"
                >
                  <FaTrash />
                </button>
              </div>
            </div>
          )
        )}

        {newRoad && (
          <div className="flex items-center space-x-4">
            <input
              type="text"
              placeholder="Name"
              value={newRoad.name}
              onChange={(e) => setNewRoad({ ...newRoad, name: e.target.value })}
              className="border-gray-300 rounded shadow-sm px-2 py-1 w-1/4"
            />
            <button
              className="text-green-600 hover:text-green-500"
              title="Show on Map"
            >
              <FaMapMarkerAlt />
            </button>
            <input
              type="text"
              placeholder="Start Time"
              value={newRoad.startTime}
              onChange={(e) =>
                setNewRoad({ ...newRoad, startTime: e.target.value })
              }
              className="border-gray-300 rounded shadow-sm px-2 py-1 w-1/4"
            />
            <input
              type="text"
              placeholder="End Time"
              value={newRoad.endTime}
              onChange={(e) =>
                setNewRoad({ ...newRoad, endTime: e.target.value })
              }
              className="border-gray-300 rounded shadow-sm px-2 py-1 w-1/4"
            />
            <button
              onClick={handleSaveNewRoad}
              className="bg-green-600 text-white px-2 py-1 rounded hover:bg-green-500"
            >
              <FaCheck />
            </button>
            <button
              onClick={handleCancelNewRoad}
              className="bg-red-600 text-white px-2 py-1 rounded hover:bg-red-500"
            >
              <FaTimes />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClosedRoadsList;
