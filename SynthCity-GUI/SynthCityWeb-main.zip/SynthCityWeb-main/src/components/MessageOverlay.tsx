import {
  FaInfoCircle,
  FaCheckCircle,
  FaExclamationCircle,
  FaTimes,
} from "react-icons/fa";

interface MessageOverlayProps {
  message: string;
  type: MessageOverlayType;
  onDismiss?: () => void;
}

type MessageOverlayType = "loader" | "success" | "error" | "info";

const MessageOverlay = (props: MessageOverlayProps) => {
  const { message, type, onDismiss } = props;
  const iconMap = {
    info: <FaInfoCircle className="text-blue-500 text-3xl" />,
    success: <FaCheckCircle className="text-green-500 text-3xl" />,
    error: <FaExclamationCircle className="text-red-500 text-3xl" />,
    loader: (
      <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin"></div>
    ),
  };

  return (
    <div
      className="fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center"
      style={{ zIndex: 99999 }}
    >
      <div className="bg-white p-8 rounded-2xl shadow-xl relative min-w-96 max-w-lg text-center">
        {onDismiss && !(type === "loader") && (
          <button
            onClick={onDismiss}
            className="absolute top-4 right-4 text-gray-600 hover:text-gray-900"
            aria-label="Dismiss"
          >
            <FaTimes className="text-xl" />
          </button>
        )}
        <div className="flex flex-col items-center space-y-6">
          <div>{iconMap[type]}</div>
          <p className="text-xl font-semibold text-gray-700">{message}</p>
        </div>
      </div>
    </div>
  );
};

export default MessageOverlay;
