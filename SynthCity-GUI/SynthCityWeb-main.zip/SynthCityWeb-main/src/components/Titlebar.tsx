import React from "react";

const TitleBar: React.FC = () => {
  return (
    <div className="bg-green-700 text-white p-4 text-xl font-bold">
      <a href="/">SynthCity</a>
    </div>
  );
};

export default TitleBar;
