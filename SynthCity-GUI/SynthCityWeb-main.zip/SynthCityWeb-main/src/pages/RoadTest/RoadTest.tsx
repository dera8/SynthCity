import "leaflet/dist/leaflet.css";
// Fix missing marker icons in Vite
/*delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: new URL(
    "leaflet/dist/images/marker-icon-2x.png",
    import.meta.url
  ).href,
  iconUrl: new URL("leaflet/dist/images/marker-icon.png", import.meta.url).href,
  shadowUrl: new URL("leaflet/dist/images/marker-shadow.png", import.meta.url)
    .href,
});*/

const RoadTest = () => {
  return (
    <div className="flex-1">
      <input
        type="text"
        placeholder="Next input"
        className="border border-gray-300 rounded px-3 py-2"
      />
    </div>
  );
};
export default RoadTest;
