import { useState, useEffect, useCallback } from "react";
import "leaflet/dist/leaflet.css";
import Button from "../../components/Button";
import RoadList from "../../components/RoadClosure/RoadList";
import RoadMap from "../../components/RoadClosure/RoadMap";
import { LatLngExpression } from "leaflet";
import {
  FileInfo,
  FileType,
  FullFileInfoFileData,
  GroupedRoad,
  NetworkInfo,
  RoadClosure,
  RoadClosureRequest,
} from "../../api/generated";
import { coordinatesParser } from "../../api/parsers/networkParsers";
import MessageOverlay from "../../components/MessageOverlay";
import { useFilePost } from "../../hooks/useFilePost";
import { useFileDownload } from "../../hooks/useFileDownload";
import RoadAutocomplete from "../../components/RoadClosure/RoadAutocomplete";
import FileSelector from "../../components/FileSelector";

const RoadClosureComponent = () => {
  const [closedStreets, setClosedStreets] = useState([] as RoadClosure[]);
  const [streetName, setStreetName] = useState("");
  const [startTime, setStartTime] = useState(0);
  const [endTime, setEndTime] = useState(23);
  const [mapCenter, setMapCenter] = useState<LatLngExpression>();
  const [selectedStreet, setSelectedStreet] = useState<string>("");
  const [success, setSuccess] = useState(false);
  const [notReady, setNotReady] = useState(false);
  const [roads, setRoads] = useState<GroupedRoad[]>([]);
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [fileData, setFileData] = useState<FullFileInfoFileData | null>(null);

  const { postRoadClosure, postError, fileInfo: newFile } = useFilePost();
  const { downloadFile } = useFileDownload();

  const handleCenterMap = () => {
    const street = roads.find((s) => s.name === streetName);
    if (street && street.edges && street.edges.length > 0) {
      let sumLat = 0,
        sumLon = 0;
      let count = 0;
      street.edges[0].path.forEach((coordinate) => {
        sumLat += coordinate.latitude;
        sumLon += coordinate.longitude;
        count++;
      });
      const avgLat = sumLat / count;
      const avgLon = sumLon / count;
      setSelectedStreet(street.name);
      setMapCenter([avgLat, avgLon]);
    } else {
      setSelectedStreet("");
      alert("Street not found");
    }
  };
  const handleCloseStreet = () => {
    if (streetName !== "") {
      const closedStreet = {
        name: streetName,
        startTime: startTime.toString(),
        endTime: endTime.toString(),
      } as RoadClosure;

      setClosedStreets([...closedStreets, closedStreet]);
      console.log(closedStreets);
      setSelectedStreet("");
      setStreetName("");
      setStartTime(0);
      setEndTime(23);
    }
  };

  const handleGenerateClosure = useCallback(() => {
    if (fileInfo) {
      const closureRequest: RoadClosureRequest = {
        type: "road_closure",
        networkId: fileInfo?.fileId,
        roadList: closedStreets,
      };
      postRoadClosure(FileType.RoadClosure, closureRequest);
    }
  }, [fileInfo, closedStreets]);

  useEffect(() => {
    if (fileData) {
      setRoads((fileData as NetworkInfo)?.roadList?.roads ?? []);
      setMapCenter(coordinatesParser((fileData as NetworkInfo).mapCenter));
    }
  }, [fileData]);

  useEffect(() => {
    if (fileInfo) {
      setNotReady(fileInfo.fileStatus !== "completed");
    }
  }, [fileInfo]);

  useEffect(() => {
    if (newFile) {
      downloadFile(newFile.fileId).then((_) => setSuccess(true));
    }
  }, [newFile]);

  const resetFileUpload = () => {};

  const handleDismissMessage = () => {
    setSuccess(false);
    resetFileUpload();
    setFileInfo(null);
    setFileData(null);
    setRoads([]);
    setMapCenter(undefined);
    setNotReady(false);
  };

  const handleAddRoad = (roads: GroupedRoad[]) => {
    setRoads((prev) => [...prev, ...roads]);
  };

  return (
    <div className="flex-1 h-full p-6">
      {notReady && (
        <MessageOverlay
          type="info"
          message={`The file is currently elaborating. When ready it will be available in the list of files with the name '${fileInfo?.fileName}'.`}
          onDismiss={handleDismissMessage}
        />
      )}
      {success && (
        <MessageOverlay
          type="success"
          message="File successfully generated."
          onDismiss={handleDismissMessage}
        />
      )}
      {postError && (
        <MessageOverlay
          type="error"
          message={`Error generating the file: ${postError}`}
          onDismiss={resetFileUpload}
        />
      )}
      <h1 className="text-2xl font-semibold mb-4">Close Roads</h1>
      <p className="text-base leading-relaxed">
        In this section you can create an XML file that specifies road closures
        based on time intervals.
      </p>
      <div className="pb-4">
        <p className="font-semibold mb-2 text-green-700">
          To generate a closure file, follow these steps:
        </p>
        <ol className="list-decimal list-inside space-y-1 text-base leading-relaxed marker:text-green-700 marker:font-semibold">
          <li>
            Upload your network file <em>or</em> select one already available.
          </li>
          <li>Search and select the road you want to close.</li>
          <li>Adjust the starting and ending hour of closure.</li>
          <li>
            Click on <span className="text-green-700">Add</span> to add it to
            the list
          </li>
          <li>
            Click "Generate Closure XML" and wait for the file to download
          </li>
        </ol>
      </div>
      <div
        className="grid grid-cols-6 gap-2 h-[calc(100vh-3rem)]"
        style={{ gridTemplateRows: "repeat(8, minmax(0, 1fr))" }}
      >
        <div className={`${!fileInfo ? "col-span-6" : "col-span-3"}`}>
          <FileSelector
            fileType={FileType.Network}
            fileStatus="completed"
            fileInfo={fileInfo}
            setFileInfo={setFileInfo}
            setFileData={setFileData}
            label={"SUMO Network File"}
            projectId={1}
            loadingMessage="Uploading network"
            retrievingMessage="Retrieving network streets"
            withRetrieve
          />
        </div>
        {/* Controls */}
        {fileInfo?.fileStatus && fileInfo?.fileStatus === "completed" && (
          <>
            <div className="row-start-2 col-span-2 mb-4">
              <label className="mb-1 font-medium">Street Name:</label>
              <RoadAutocomplete
                inputValue={streetName}
                onInputChange={setStreetName}
                roads={roads}
                addRoads={handleAddRoad}
                resetRoads={() => setRoads([])}
                selectedFile={fileInfo.fileId}
              />
            </div>
            <div className="row-start-3 col-start-1 col-span-1 mb-4">
              <label className="mb-1 font-medium">Start Time:</label>
              <input
                type="number"
                max={23}
                min={0}
                step={1}
                value={startTime}
                onChange={(e) => setStartTime(e.target.valueAsNumber)}
                className="w-full p-2 border rounded focus:outline-none  focus:ring-2 focus:ring-green-500"
              />
            </div>
            <div className="row-start-3 col-start-2 col-span-1 mb-4">
              <label className="mb-1 font-medium">End Time:</label>
              <input
                type="number"
                max={23}
                min={0}
                step={1}
                value={endTime}
                onChange={(e) => setEndTime(e.target.valueAsNumber)}
                className="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
            <div className="row-start-3 col-start-3 col-span-1 mb-4 flex justify-evenly mt-8">
              <Button onClick={handleCenterMap} label="Find" />
              <Button label="Add" onClick={handleCloseStreet} />
            </div>

            {/* Map */}
            {mapCenter && (
              <div className="col-span-3 row-span-7 col-start-4">
                <RoadMap
                  mapCenter={mapCenter}
                  streets={roads}
                  selectedStreet={selectedStreet}
                />
              </div>
            )}

            {/* List */}
            <div className="col-span-3 row-span-4 h-full">
              <div className="h-full overflow-y-auto pr-2">
                <RoadList items={closedStreets} onUpdate={setClosedStreets} />
              </div>
            </div>
            <div className="row-start-8 col-span-3">
              <Button
                label="Generate Closure XML"
                enabled={closedStreets.length > 0}
                onClick={handleGenerateClosure}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default RoadClosureComponent;
