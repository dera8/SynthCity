import SectionInfoCard from "../../components/SectionInfoCard";

const Home = () => {
  const sections = [
    {
      title: "Dashboard",
      intro:
        "An overview of the uploaded or generated files and the available operations.",
      href: "dashboard",
    },
    {
      title: "Modify GTFS",
      intro:
        "The scripts used to manipulate the GTFS files. In here you can delete stops or modify routes from the given GTFS archive file.",
      href: "modify-gtfs",
    },
    {
      title: "Close Roads",
      intro:
        "Upload a SUMO network file and choose the roads you want to close to the traffic. It generates an additional file to use in your SUMO simulation.",
      href: "close-roads",
    },
    {
      title: "Modify OD Matricies",
      intro:
        "Upload a origin-destination matrix file and either add or substract a number or percentage of trips from-to the chosen zones.",
      href: "modify-matrices",
    },
    {
      title: "Data Generation",
      intro:
        "The scripts used to generate new files to add stops, edges or trips to your simulation.",
      href: "data-generation",
    },
  ];

  return (
    <div className="px-6 py-2 text-gray-800">
      <h1 className="text-4xl font-bold text-green-700 mb-4">SynthCity Web</h1>
      <p className="text-lg mb-4">
        This web app is a web interface to the SynthCity tool, a set of scripts
        designed to enhance traffic simulation workflows with SUMO. <br />
        It gives a graphical interface to the scripts and offers a comprehensive
        overview of the files generated through them.
      </p>
      <p className="text-lg mb-8">
        <a
          href="https://sumo.dlr.de/docs/index.html"
          target="_blank"
          className="text-green-600 hover:underline"
        >
          Read more about SUMO
        </a>
        <br />
        <a
          href="https://github.com/dera8/SynthCity"
          target="_blank"
          className="text-green-600 hover:underline"
        >
          Read more about SynthCity
        </a>
      </p>
      <h2 className="text-2xl font-semibold text-green-700 mb-2">Overiew</h2>
      <p className="mb-6"></p>
      <p className="mb-6">
        The following are the main sections of the application.
      </p>
      <div className="mt-6 overflow-x-auto">
        <div className="flex space-x-4 min-w-max">
          {sections.map((section) => (
            <SectionInfoCard
              key={section.href}
              title={section.title}
              desc={section.intro}
              link={section.href}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;
