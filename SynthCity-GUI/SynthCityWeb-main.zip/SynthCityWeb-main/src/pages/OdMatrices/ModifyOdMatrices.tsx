import { useCallback, useEffect, useState } from "react";
import Button from "../../components/Button";
import RadioButton from "../../components/RadioButton";
import {
  FileType,
  OdMatrixModification,
  OdMatrixInfo,
  ModifyOdMatrixRequest,
  ActionCommandTypes,
  ActionValueTypes,
  FileInfo,
  FullFileInfoFileData,
} from "../../api/generated";
import { useFilePost } from "../../hooks/useFilePost";
import { useFileDownload } from "../../hooks/useFileDownload";
import MessageOverlay from "../../components/MessageOverlay";
import FileSelector from "../../components/FileSelector";

const ModifyOdMatrices = () => {
  const [actionCommandType, setActionCommandtype] =
    useState<ActionCommandTypes>(ActionCommandTypes.Add);
  const [valueType, setValueType] = useState<ActionValueTypes>(
    ActionValueTypes.Value
  );
  const [valueInput, setValueInput] = useState<number>(0);
  const [originZone, setOriginZone] = useState<string | null>(null);
  const [destinationZone, setDestinationZone] = useState<string | null>(null);
  const [zones, setZones] = useState<string[]>([]);
  const [actions, setActions] = useState<OdMatrixModification[]>([]);
  const [newName, setNewName] = useState<string>("");
  const [nameError, setNameError] = useState<string | null>(null);
  const {
    postModifyOdMatrix,
    postError,
    fileInfo: newInfo,
    resetPostFile,
  } = useFilePost();
  const { downloadFile, downloadError } = useFileDownload();
  const [success, setSuccess] = useState(false);
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [fileData, setFileData] = useState<FullFileInfoFileData | null>(null);
  useEffect(() => {
    console.log("fileData ", fileData);
    if (fileData) {
      const odInfo = fileData as OdMatrixInfo;
      const infoZones = odInfo.zones.sort((a, b) => {
        const numA = parseInt(a, 10);
        const numB = parseInt(b, 10);

        const isNumA = !isNaN(numA) && a.trim() === numA.toString();
        const isNumB = !isNaN(numB) && b.trim() === numB.toString();

        if (isNumA && isNumB) {
          return numA - numB;
        } else {
          return a.localeCompare(b);
        }
      });
      setZones(infoZones);
    }
  }, [fileData]);

  const handleAddAction = () => {
    if (!originZone || !destinationZone || valueInput === 0) return;
    const newAction: OdMatrixModification = {
      fromZone: originZone,
      toZones: [destinationZone],
      action: actionCommandType,
      value: valueInput,
    };
    setActions((prev) => [...prev, newAction]);
  };

  const handleSubmit = useCallback(() => {
    let valid = true;

    if (!newName.trim()) {
      setNameError("The filename for the new file is needed.");
      valid = false;
    }

    if (!valid || !fileInfo) return;

    const request: ModifyOdMatrixRequest = {
      type: "modify_od",
      matrixId: fileInfo.fileId,
      modifications: actions,
      actionValueType: valueType,
      newFileName: newName,
    };

    fileInfo && postModifyOdMatrix(FileType.Odmatrix, request);
    console.log("Filename:", newName);
  }, [newName, actions, valueType]);

  useEffect(() => {
    if (newInfo?.fileId) {
      downloadFile(newInfo.fileId).then((_) => setSuccess(true));
    }
  }, [newInfo]);
  const resetPage = () => {
    setSuccess(false);
    resetPostFile();
    setActions([]);
    setNewName("");
    setNameError(null);
    setValueInput(0);
    setFileInfo(null);
    setFileData(null);
    setZones([]);
    setDestinationZone(null);
    setOriginZone(null);
  };

  return (
    <div className="p-6 space-y-6 ">
      {postError && (
        <MessageOverlay
          message={`Generation error: ${postError}`}
          type={"error"}
          onDismiss={resetPostFile}
        />
      )}
      {downloadError && (
        <MessageOverlay
          message={`Download error: ${downloadError}`}
          type={"error"}
        />
      )}
      {success && (
        <MessageOverlay
          message="File generated sucessfully!"
          onDismiss={resetPage}
          type="success"
        />
      )}
      <h1 className="text-2xl font-semibold mb-4">Modify OD Matrix</h1>
      <div className="w-3/4">
        <p className="text-base leading-relaxed">
          <strong className="text-green-700">Origin/Destination Matrix</strong>{" "}
          describes the number of vehicles moving from one TAZ to another in the
          network during a specific hour of the day. A TAZ (Traffic Analysis
          Zone) is a group of edges identified by an ID.{" "}
          <a
            href="https://sumo.dlr.de/docs/Demand/Importing_O/D_Matrices.html#describing_the_taz"
            target="_blank"
            className="text-green-700 hover:underline"
          >
            Read more about TAZ on SUMO documentation
          </a>{" "}
          .
        </p>

        <p className="text-base leading-relaxed">
          In this section, you can upload an OD Matrix file and modify the
          values—by absolute number or percentage—of vehicles moving between
          selected zones.
        </p>

        <p className="text-base leading-relaxed">
          Zones are extracted from the file itself, so the list may be
          incomplete. In the future, you may be able to add entries manually or
          upload a full TAZ file.
        </p>
        <p></p>
        <div>
          <p className="font-semibold mb-2 text-green-700">
            To generate a modified matrix, follow these steps:
          </p>
          <ol className="list-decimal list-inside space-y-1 text-base leading-relaxed marker:text-green-700 marker:font-semibold">
            <li>Upload your OD Matrix file.</li>
            <li>
              Choose the type of operation: percentage or absolute value{" "}
              <em>Attention! this choice affects all the modifications!</em>
            </li>
            <li>Select the origin and destination zones</li>
            <li>Choose an operation: either add or subtract</li>
            <li>Enter the desired value</li>
            <li>
              Click on <span className="text-green-700">Add Action</span> to add
              it to the list
            </li>
            <li>Name the new file</li>
            <li>Click "Generate" and wait for the file to download</li>
          </ol>
        </div>
      </div>

      <div className="w-full">
        <FileSelector
          fileType={FileType.Odmatrix}
          label={"OD Matrix"}
          projectId={1}
          fileInfo={fileInfo}
          setFileData={setFileData}
          setFileInfo={setFileInfo}
          loadingMessage="Uploading OD File"
          retrievingMessage="Retriving OD File"
          withRetrieve
        />
      </div>

      {zones.length > 0 && (
        <>
          <div className="mt-6">
            <span className="block font-semibold mb-2">Modify By</span>
            <RadioButton
              name="group2"
              options={[
                { label: "Value", value: ActionValueTypes.Value },
                {
                  label: ActionValueTypes.Percentage,
                  value: ActionValueTypes.Percentage,
                },
              ]}
              selectedValue={valueType}
              onChange={(value) => {
                setValueType(value as ActionValueTypes);
                setValueInput(0);
              }}
            />
          </div>

          <div className="flex space-x-6 mt-6">
            <div className="w-1/2">
              <span className="block font-semibold mb-2">
                Select Origin Zone
              </span>
              <div className="border border-gray-300 rounded overflow-y-auto h-40">
                {zones.map((zone) => (
                  <div
                    key={zone}
                    onClick={() => setOriginZone(zone)}
                    className={`p-2 cursor-pointer ${
                      originZone === zone
                        ? "bg-green-500 text-white"
                        : "hover:bg-gray-200"
                    }`}
                  >
                    {zone}
                  </div>
                ))}
              </div>
            </div>

            <div className="w-1/2">
              <span className="block font-semibold mb-2">
                Selection Destination Zone
              </span>
              <div className="border border-gray-300 rounded overflow-y-auto h-40">
                {zones.map((zone) => (
                  <div
                    key={zone}
                    onClick={() => setDestinationZone(zone)}
                    className={`p-2 cursor-pointer ${
                      destinationZone === zone
                        ? "bg-green-500 text-white"
                        : "hover:bg-gray-200"
                    }`}
                  >
                    {zone}
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="mt-6">
            <span className="block font-semibold mb-2">Select operation</span>
            <RadioButton
              name="operation"
              options={[
                { label: "Add", value: ActionCommandTypes.Add },
                { label: "Subtract", value: ActionCommandTypes.Subtract },
              ]}
              selectedValue={actionCommandType}
              onChange={(value) =>
                setActionCommandtype(value as ActionCommandTypes)
              }
            />
          </div>
          <div className="mt-6">
            <span className="block font-semibold mb-2">Value</span>
            <div className="mt-4">
              <input
                type="number"
                min={0}
                max={
                  valueType === ActionValueTypes.Percentage ? 100 : undefined
                }
                step={valueType === ActionValueTypes.Percentage ? 1 : undefined}
                value={valueInput}
                onChange={(e) => setValueInput(e.target.valueAsNumber)}
                placeholder={
                  valueType === ActionValueTypes.Value
                    ? "Enter absolute value"
                    : "Enter percentage"
                }
                className="border border-gray-300 rounded px-4 py-2 w-full focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
            <div className="mt-4">
              <Button label={"Add action"} onClick={handleAddAction} />
            </div>
          </div>
          <span className="block font-semibold">Actions List</span>
          <div
            id="list"
            className="mt-4 max-h-48 overflow-y-auto border border-gray-300 rounded p-4 space-y-2"
          >
            {actions.length === 0 && (
              <span>
                <em className="text-green-700">No actions added.</em>
              </span>
            )}
            {actions.length > 0 &&
              actions.map((action) => (
                <p>{`form ${action.fromZone} to ${action.toZones}  ${
                  action.action
                } ${action.value} ${
                  valueType === ActionValueTypes.Percentage ? "%" : ""
                }`}</p>
              ))}
          </div>
          {actions.length > 0 && (
            <div>
              <span className="block font-semibold">New File Name</span>
              <input
                type="text"
                id="filename"
                placeholder="Specify the new file name here."
                value={newName}
                className={`block my-4 w-full border rounded shadow-sm px-4 py-2 focus:ring-green-500 focus:border-green-500 transition-all
                  ${nameError ? "border-red-500" : "border-gray-300"}`}
                onChange={(e) => {
                  setNewName(e.target.value);
                  if (nameError) setNameError(null);
                }}
              />
              {nameError && (
                <p className="text-red-500 text-sm mt-1">{nameError}</p>
              )}
              <Button label={"Generate"} onClick={handleSubmit} />
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default ModifyOdMatrices;
