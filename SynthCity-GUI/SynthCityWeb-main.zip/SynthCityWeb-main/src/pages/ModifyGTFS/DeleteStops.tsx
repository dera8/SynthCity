import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import {
  FileInfo,
  FileType,
  FullFileInfoFileData,
  GtfsInfo,
  ModifyGtfsRequestBody,
  ModifyGtfsStopsRequest,
} from "../../api/generated";
import Button from "../../components/Button";
import FilteredMultiSelect from "../../components/FilteredMultiSelect";
import { useFileDownload } from "../../hooks/useFileDownload";
import { useFileUpdate } from "../../hooks/useFileUpdate";
import MessageOverlay from "../../components/MessageOverlay";
import FileSelector from "../../components/FileSelector";

const DeleteStops = () => {
  const [value, setValue] = useState<number | null>(null);
  const [selectedStops, setSelectedStops] = useState<string[]>([]);
  const [nameError, setNameError] = useState<string | null>(null);
  const [routesError, setStopsError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const nameRef = useRef<HTMLInputElement>(null);
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [fileData, setFileData] = useState<FullFileInfoFileData | null>(null);

  const {
    updateFile,
    fileInfo: updatedGtfs,
    loading: updating,
  } = useFileUpdate();
  const { downloadFile, loading: downloading } = useFileDownload();

  const options = useMemo(() => {
    if (fileData == null) return null;
    return (fileData as GtfsInfo).stopsInfo.stops.map(
      (stop) => `${stop.stop_id}`
    );
  }, [fileData]);

  const getOptionLabel = useCallback(
    (option: string) => {
      return (fileData as GtfsInfo)?.stopsInfo.stops
        .filter((stop) => stop.stop_id === option)
        .map((stop) => `${stop.stop_id} - ${stop.stop_name}`)[0];
    },
    [fileData]
  );

  const handleSubmit = () => {
    let valid = true;

    if (!nameRef.current?.value) {
      setNameError("The filename for the new file is needed.");
      valid = false;
    }

    if (selectedStops.length === 0) {
      setStopsError("You must select at least one route.");
      valid = false;
    }

    if (!valid) return;

    const request: ModifyGtfsRequestBody = {
      type: "modify_gtfs_request",
      request: {
        type: "modify_gtfs_stops_request",
        filename: nameRef.current?.value,
        stops_ids: selectedStops,
      } as ModifyGtfsStopsRequest,
    };

    fileInfo && updateFile(fileInfo?.fileId, request);
    console.log("Filename:", nameRef.current?.value);
    console.log("Percentage:", value);
    console.log("Selected Stops:", selectedStops);
  };

  console.log("rendering DeleteStops");

  useEffect(() => {
    if (!updatedGtfs) return;
    downloadFile(updatedGtfs.fileId).then((_) => setSuccess(true));
  }, [updatedGtfs]);

  const handleDismissMessage = () => {
    setSuccess(false);
    setValue(null);
    setSelectedStops([]);
    setFileInfo(null);
    setFileData(null);
  };

  const memoizedOptions = useMemo(() => {
    console.log("memoizedOptions");
    return options;
  }, [options]);
  const memoizedGetOptionLabel = useCallback(getOptionLabel, [getOptionLabel]);
  return (
    <div className="flex-1 py-6">
      {(updating || downloading) && (
        <MessageOverlay
          type={"loader"}
          message="Downloading the genereted file..."
        />
      )}
      {success && (
        <MessageOverlay
          type="success"
          message="File successfully generated."
          onDismiss={handleDismissMessage}
        />
      )}
      <h1 className="text-xl font-semibold mb-4">Delete GTFS Stops</h1>
      <p className="text-base leading-relaxed">
        In this subsection you can modify the given GTFS file by deleting
        specific stops from the <span className="text-green-700">stop.txt</span>{" "}
        file.
      </p>
      <div>
        <p className="font-semibold mb-2 text-green-700">
          To delete stops, follow these steps:
        </p>
        <ol className="list-decimal list-inside space-y-1 text-base leading-relaxed marker:text-green-700 marker:font-semibold">
          <li>Upload your GTFS file.</li>
          <li>Select one or more stops.</li>
          <li>Specify the new file name.</li>
          <li>Click on the button and wait for the file to download</li>
        </ol>
      </div>
      <form className="space-y-4">
        <div>
          <FileSelector
            fileType={FileType.Gtfs}
            label={"GTFS Zip File"}
            projectId={1}
            fileInfo={fileInfo}
            setFileInfo={setFileInfo}
            setFileData={setFileData}
            loadingMessage="Uploading GTFS file"
            retrievingMessage="Retrieving GTFS data"
            withRetrieve
            onReset={handleDismissMessage}
          />
        </div>
        {memoizedOptions && (
          <div className="w-100">
            <span className="font-medium">Select stops to delete</span>
            <FilteredMultiSelect<string>
              options={memoizedOptions}
              validationError={routesError}
              setSelectedItems={setSelectedStops}
              getOptionLabel={memoizedGetOptionLabel}
              selectedItems={selectedStops}
            />
          </div>
        )}

        {fileData && (
          <>
            <div>
              <label
                htmlFor="filename"
                className="block text-gray-700 font-medium mb-2"
              >
                New File Name
              </label>
              <input
                type="text"
                id="filename"
                placeholder="Specify the new file name here."
                ref={nameRef}
                className={`block w-full border rounded shadow-sm px-4 py-2 focus:ring-green-500 focus:border-green-500 transition-all
                  ${nameError ? "border-red-500" : "border-gray-300"}`}
              />
              {nameError && (
                <p className="text-red-500 text-sm mt-1">{nameError}</p>
              )}
            </div>

            <Button
              label="Download Modified GTFS File"
              onClick={handleSubmit}
            />
          </>
        )}
      </form>
    </div>
  );
};

export default DeleteStops;
