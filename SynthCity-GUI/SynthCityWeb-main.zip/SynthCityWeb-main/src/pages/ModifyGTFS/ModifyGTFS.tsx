import { Outlet } from "react-router-dom";

const ModifyGTFS = () => {
  return (
    <div className="flex-1 p-6">
      <h1 className="text-2xl font-semibold mb-4">Modify GTFS File</h1>
      <div className="w-3/4">
        <p className="text-base leading-relaxed">
          <strong className="text-green-700">GTFS</strong> is a standardized
          format for public transportation schedules. It Typically includes
          informations about <span className="text-green-700">routes</span>,{" "}
          <span className="text-green-700">stops</span>,{" "}
          <span className="text-green-700">trips</span> and{" "}
          <span className="text-green-700">schedules</span>.{" "}
        </p>
        <p>
          <a
            href="https://developers.google.com/transit/gtfs"
            target="_blank"
            className="text-green-700 hover:underline"
          >
            Read more about GTFS feeds on Google developer documentation
          </a>{" "}
          .
        </p>
      </div>
      <Outlet />
    </div>
  );
};
export default ModifyGTFS;
