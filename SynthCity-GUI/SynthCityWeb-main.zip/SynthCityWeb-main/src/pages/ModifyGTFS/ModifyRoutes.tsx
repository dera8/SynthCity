import FilteredMultiSelect from "../../components/FilteredMultiSelect";
import Button from "../../components/Button";
import {
  FileInfo,
  FileType,
  FullFileInfoFileData,
  GtfsInfo,
  ModifyGtfsRequestBody,
  ModifyGtfsTripsRequest,
} from "../../api/generated";
import { useCallback, useEffect, useMemo, useState } from "react";
import MessageOverlay from "../../components/MessageOverlay";
import { useFileUpdate } from "../../hooks/useFileUpdate";
import { useFileDownload } from "../../hooks/useFileDownload";
import FileSelector from "../../components/FileSelector";

const ModifyRoutes = () => {
  const [newName, setNewName] = useState<string>("");
  const [value, setValue] = useState<number | null>(null);
  const [selectedRoutes, setSelectedRoutes] = useState<string[]>([]);
  const [nameError, setNameError] = useState<string | null>(null);
  const [valueError, setValueError] = useState<string | null>(null);
  const [routesError, setRoutesError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [fileInfo, setFileInfo] = useState<FileInfo | null>(null);
  const [fileData, setFileData] = useState<FullFileInfoFileData | null>(null);
  const {
    updateFile,
    updateError,
    fileInfo: updatedGtfs,
    loading: updating,
  } = useFileUpdate();
  const { downloadFile, loading: downloading } = useFileDownload();

  const options = useMemo(() => {
    if (fileData == null) return null;
    return (fileData as GtfsInfo).tripsInfo.trips.map(
      (trip) => `${trip.route_id}`
    );
  }, [fileData]);

  const getOptionLabel = useCallback(
    (option: string) => {
      return (fileData as GtfsInfo)?.tripsInfo.trips
        .filter((trip) => trip.route_id === option)
        .map((trip) => `${trip.route_id} - ${trip.route_name}`)[0];
    },
    [fileData]
  );

  const handleSubmit = () => {
    let valid = true;

    if (!newName.trim()) {
      setNameError("The filename for the new file is needed.");
      valid = false;
    }

    if (value === null || value < 0 || value > 100) {
      setValueError("Please enter a percentage between 0 and 100.");
      valid = false;
    }

    if (selectedRoutes.length === 0) {
      setRoutesError("You must select at least one route.");
      valid = false;
    }

    if (!valid) return;

    const request: ModifyGtfsRequestBody = {
      type: "modify_gtfs_request",
      request: {
        type: "modify_gtfs_trips_request",
        filename: newName,
        value: value,
        routes_ids: selectedRoutes,
      } as ModifyGtfsTripsRequest,
    };

    fileInfo && updateFile(fileInfo?.fileId, request);
    console.log("Filename:", newName);
    console.log("Percentage:", value);
    console.log("Selected Routes:", selectedRoutes);
  };

  useEffect(() => {
    console.log(updateError);
  }, [updateError]);

  useEffect(() => {
    console.log(updatedGtfs);
    if (updatedGtfs) {
      downloadFile(updatedGtfs.fileId).then((_) => setSuccess(true));
    }
  }, [updatedGtfs]);

  const handleDismissMessage = () => {
    setSuccess(false);
    setNewName("");
    setValue(null);
    setSelectedRoutes([]);
    setFileInfo(null);
    setFileData(null);
  };

  return (
    <div className="flex-1 py-6">
      {(updating || downloading) && (
        <MessageOverlay
          type={"loader"}
          message="Downloading the genereted file..."
        />
      )}
      {success && (
        <MessageOverlay
          type="success"
          message="File successfully generated."
          onDismiss={handleDismissMessage}
        />
      )}
      <h1 className="text-xl font-semibold mb-4">Modify GTFS Routes</h1>
      <p className="text-base leading-relaxed">
        In this subsection you can modify the given GTFS file by deleting a
        percentages of trips from the{" "}
        <span className="text-green-700">trips.txt</span> file.
      </p>
      <div>
        <p className="font-semibold mb-2 text-green-700">
          To delete trips, follow these steps:
        </p>
        <ol className="list-decimal list-inside space-y-1 text-base leading-relaxed marker:text-green-700 marker:font-semibold">
          <li>Upload your GTFS file.</li>
          <li>Select one or more trip.</li>
          <li>Specify the percentage of trips to delete.</li>
          <li>Specify the new file name.</li>
          <li>Click on the button and wait for the file to download</li>
        </ol>
      </div>
      <form className="space-y-4">
        <div>
          <FileSelector
            fileType={FileType.Gtfs}
            projectId={1}
            label="GTFS Zip File"
            fileInfo={fileInfo}
            setFileInfo={setFileInfo}
            setFileData={setFileData}
            loadingMessage="Uploading the GTFS File"
            retrievingMessage="Retrieving the GTFS File"
            withRetrieve
          />
        </div>
        {options && (
          <div className="w-100">
            <span className="font-medium">Select routes to modify</span>
            <FilteredMultiSelect<string>
              options={options}
              validationError={routesError}
              setSelectedItems={setSelectedRoutes}
              selectedItems={selectedRoutes}
              getOptionLabel={getOptionLabel}
            />
          </div>
        )}

        {fileData && (
          <>
            <div>
              <label
                htmlFor="number"
                className="block text-gray-700 font-medium mb-2"
              >
                Percentage
              </label>
              <input
                type="number"
                id="number"
                placeholder="0 - 100"
                max={100}
                min={0}
                className={`block w-full border rounded shadow-sm px-4 py-2 focus:ring-green-500 focus:border-green-500 transition-all
                  ${valueError ? "border-red-500" : "border-gray-300"}`}
                onChange={(e) => {
                  setValue(e.target.valueAsNumber);
                  if (valueError) setValueError(null);
                }}
                value={value ?? ""}
              />
              {valueError && (
                <p className="text-red-500 text-sm mt-1">{valueError}</p>
              )}
            </div>
            <div>
              <label
                htmlFor="filename"
                className="block text-gray-700 font-medium mb-2"
              >
                New File Name
              </label>
              <input
                type="text"
                id="filename"
                placeholder="Specify the new file name here."
                value={newName}
                className={`block w-full border rounded shadow-sm px-4 py-2 focus:ring-green-500 focus:border-green-500 transition-all
                  ${nameError ? "border-red-500" : "border-gray-300"}`}
                onChange={(e) => {
                  setNewName(e.target.value);
                  if (nameError) setNameError(null);
                }}
              />
              {nameError && (
                <p className="text-red-500 text-sm mt-1">{nameError}</p>
              )}
            </div>

            <Button
              label="Download Modified GTFS File"
              onClick={handleSubmit}
            />
          </>
        )}
      </form>
    </div>
  );
};

export default ModifyRoutes;
