import { useCallback, useEffect, useMemo, useState } from "react";
import Button from "../../components/Button";
import DatePicker from "../../components/DatePicker";
import { FileType, SynthStopsRequest, FileInfo } from "../../api/generated";
import { useFileDownload } from "../../hooks/useFileDownload";
import { useFilePost } from "../../hooks/useFilePost";
import MessageOverlay from "../../components/MessageOverlay";
import FileSelector from "../../components/FileSelector";

const StopGeneration = () => {
  const synthFilePost = useFilePost();
  const synthDownload = useFileDownload();
  const [stopDataInfo, setStopDataInfo] = useState<FileInfo | null>(null);
  const [stopSimInfo, setStopSimInfo] = useState<FileInfo | null>(null);
  const [gtfsInfo, setGtfsInfo] = useState<FileInfo | null>(null);
  const [success, setSuccess] = useState(false);
  const [newName, setNewName] = useState<string>("");
  const [nameError, setNameError] = useState<string | null>(null);
  const [arrivalDateError, setArrivalDateError] = useState<string | null>(null);
  const [selectedArrivalDate, setSelectedArrivalDate] = useState<string>("");
  const [departureDateError, setDepartureDateError] = useState<string | null>(
    null
  );
  const [selectedDepartureDate, setSelectedDepartureDate] =
    useState<string>("");
  const [startDateError, setStartDateError] = useState<string | null>(null);
  const [selectedStartDate, setSelectedStartDate] = useState<string>("");

  const isGtfsPresent = useMemo(() => {
    return gtfsInfo != null;
  }, [gtfsInfo]);

  const isStopSimPresent = useMemo(() => {
    return stopSimInfo != null;
  }, [stopSimInfo]);

  const isStopDataPresent = useMemo(() => {
    return stopDataInfo != null;
  }, [stopDataInfo]);

  const handleArrivalDateSelected = (dateStr: string) => {
    const date = new Date(dateStr);
    if (arrivalDateError) setArrivalDateError(null);
    if (isNaN(date.getTime())) {
      setArrivalDateError("Invalide date selected");
      return;
    }
    setSelectedArrivalDate(dateStr);
  };

  const handleDepartureDateSelected = (dateStr: string) => {
    const date = new Date(dateStr);
    if (departureDateError) setDepartureDateError(null);
    if (isNaN(date.getTime())) {
      setDepartureDateError("Invalide date selected");
      return;
    }
    setSelectedDepartureDate(dateStr);
  };

  const handleStartDateSelected = (dateStr: string) => {
    const date = new Date(dateStr);
    if (startDateError) setStartDateError(null);
    if (isNaN(date.getTime())) {
      setStartDateError("Invalide date selected");
      return;
    }
    setSelectedStartDate(dateStr);
  };

  const handleSubmit = useCallback(() => {
    let valid = true;

    if (!newName.trim()) {
      setNameError("The filename for the new file is needed.");
      valid = false;
    }
    if (selectedArrivalDate.trim() === "") {
      setArrivalDateError("The arrival date is needed.");
      valid = false;
    }
    if (selectedDepartureDate.trim() === "") {
      setDepartureDateError("The departure date is needed.");
      valid = false;
    }
    if (selectedStartDate.trim() === "") {
      setStartDateError("The start date is needed.");
      valid = false;
    }

    if (!valid || !stopSimInfo || !gtfsInfo || !stopDataInfo) return;

    const request: SynthStopsRequest = {
      type: "synth_stops",
      gtfsId: gtfsInfo.fileId,
      stopSimId: stopSimInfo.fileId,
      stopDataId: stopDataInfo.fileId,
      newFileName: newName,
      departureDateString: formatDate(selectedDepartureDate),
      arrivalDateString: formatDate(selectedArrivalDate),
      infoStartDate: formatDate(selectedStartDate),
    };

    synthFilePost.postSynthStops(FileType.SynthStops, request);
    console.log("Filename:", newName);
  }, [
    newName,
    stopDataInfo,
    stopSimInfo,
    gtfsInfo,
    selectedArrivalDate,
    selectedDepartureDate,
    selectedStartDate,
  ]);

  useEffect(() => {
    if (synthFilePost.fileInfo) {
      synthDownload
        .downloadFile(synthFilePost.fileInfo.fileId)
        .then((_) => setSuccess(true));
    }
  }, [synthFilePost.fileInfo]);

  const handleDismissMessage = () => {
    setSuccess(false);
    setNewName("");
    setSelectedArrivalDate("");
    setSelectedDepartureDate("");
    setSelectedStartDate("");
    setStopDataInfo(null);
    setGtfsInfo(null);
    setStopSimInfo(null);
  };

  const formatDate = useCallback((dateStr: string) => {
    const date = new Date(dateStr);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    const formatted = `${day}/${month}/${year}`;
    console.log("Formatted date:", formatted);
    return formatted;
  }, []);

  useEffect(() => {
    console.log(stopDataInfo);
  }, [stopDataInfo]);
  return (
    <div>
      {synthFilePost.loading && (
        <MessageOverlay
          type={"loader"}
          message="Generating Synth Stops file, it may take a while."
        />
      )}
      {success && (
        <MessageOverlay
          type="success"
          message="File successfully generated."
          onDismiss={handleDismissMessage}
        />
      )}
      <h1 className="text-2xl font-semibold mb-4">Stop Dataset Generation</h1>
      <p className="text-base leading-relaxed w-3/4">
        This sections allows you to generates a stops dataset by merging and
        processing data from GTFS files, a custom stops file, and stop output
        data. It includes handling for time corrections and delay calculations.
      </p>
      <p>To use this section, you will need:</p>
      <ul className="list-disc list-inside space-y-1 text-base leading-relaxed marker:text-green-700 marker:font-semibold">
        <li>
          Obtain the{" "}
          <a
            href="https://sumo.dlr.de/docs/Simulation/Output/StopOutput.html"
            target="_blank"
            className="text-green-700 hover:underline"
          >
            SUMO stop info output file
          </a>
          .
        </li>
        <li>
          Convert the stop file in csv using the{" "}
          <a
            href="https://sumo.dlr.de/docs/Tools/Xml.html"
            target="_blank"
            className="text-green-700 hover:underline"
          >
            xml2csv.py
          </a>{" "}
          tool provided by SUMO installation, we refer to this file as{" "}
          <span className="text-green-700">Stops Output File</span>.
        </li>
        <li>
          Process the GTFS files using the{" "}
          <a
            href="https://sumo.dlr.de/docs/Tools/Import/GTFS.html"
            target="_blank"
            className="text-green-700 hover:underline"
          >
            gtfs2pt.py
          </a>{" "}
          tool provided by SUMO installation and obtain the stop file, such as
          "gtfs_pt_stops.add.xml".
        </li>
        <li>
          Convert the gtfs stop file in csv with the{" "}
          <span className="text-green-700">xml2csv.py</span> tool.
        </li>
        <li>
          Modify the previous file, keeping only SUMO id and the name of the
          stop, we refer to this file as{" "}
          <span className="text-green-700">Simulated Stop File</span>
        </li>
        <li>
          Upload the prepared files as requested below and insert the dates.
        </li>
      </ul>
      <form className="space-y-4 py-2">
        <FileSelector
          label="Stop Output CSV File"
          fileType={FileType.StopData}
          projectId={1}
          setFileInfo={setStopDataInfo}
          fileInfo={stopDataInfo}
        />
        <FileSelector
          label="GTFS Zip File"
          fileType={FileType.Gtfs}
          projectId={1}
          setFileInfo={setGtfsInfo}
          fileInfo={gtfsInfo}
        />
        <FileSelector
          label="Simulated Stop CSV File"
          fileType={FileType.StopSim}
          projectId={1}
          setFileInfo={setStopSimInfo}
          fileInfo={stopSimInfo}
        />

        {isGtfsPresent && isStopSimPresent && isStopDataPresent && (
          <>
            <div className="py-2">
              <DatePicker
                value={selectedArrivalDate}
                onDateSelected={handleArrivalDateSelected}
              />
              {arrivalDateError && (
                <p className="text-red-500 text-sm mt-1">{arrivalDateError}</p>
              )}
            </div>
            <div className="py-2">
              <DatePicker
                value={selectedDepartureDate}
                onDateSelected={handleDepartureDateSelected}
              />
              {departureDateError && (
                <p className="text-red-500 text-sm mt-1">
                  {departureDateError}
                </p>
              )}
            </div>
            <div className="py-2">
              <DatePicker
                value={selectedStartDate}
                onDateSelected={handleStartDateSelected}
              />
              {startDateError && (
                <p className="text-red-500 text-sm mt-1">{startDateError}</p>
              )}
            </div>
            <input
              type="text"
              id="filename"
              placeholder="Specify the new file name here."
              value={newName}
              className={`block my-4 w-3/4 border rounded shadow-sm px-4 py-2 focus:ring-green-500 focus:border-green-500 transition-all
            ${nameError ? "border-red-500" : "border-gray-300"}`}
              onChange={(e) => {
                setNewName(e.target.value);
                if (nameError) setNameError(null);
              }}
            />
            {nameError && (
              <p className="text-red-500 text-sm mt-1">{nameError}</p>
            )}
            <Button label="Generate Stop file" onClick={handleSubmit} />
          </>
        )}
      </form>
    </div>
  );
};

export default StopGeneration;
