import { useCallback, useEffect, useState } from "react";
import Button from "../../components/Button";
import DatePicker from "../../components/DatePicker";
import { useFilePost } from "../../hooks/useFilePost";
import { FileInfo, FileType, SynthEdgesRequest } from "../../api/generated";
import MessageOverlay from "../../components/MessageOverlay";
import { useFileDownload } from "../../hooks/useFileDownload";
import FileSelector from "../../components/FileSelector";

const EdgeGeneration = () => {
  const synthFilePost = useFilePost();
  const synthDownload = useFileDownload();
  const [newName, setNewName] = useState<string>("");
  const [edgeInfo, setEdgeInfo] = useState<FileInfo | null>(null);
  const [tazInfo, setTazInfo] = useState<FileInfo | null>(null);
  const [nameError, setNameError] = useState<string | null>(null);
  const [dateError, setDateError] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [success, setSuccess] = useState(false);

  const handleDateSelected = (dateStr: string) => {
    const date = new Date(dateStr);
    if (dateError) setDateError(null);
    if (isNaN(date.getTime())) {
      setDateError("Invalide date selected");
      console.error("Invalid date selected");
      return;
    }

    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    const formatted = `${year}-${month}-${day}`;
    console.log("Formatted date:", formatted);
    setSelectedDate(formatted);
  };

  const handleSubmit = useCallback(() => {
    let valid = true;

    if (!newName.trim()) {
      setNameError("The filename for the new file is needed.");
      valid = false;
    }
    if (selectedDate.trim() === "") {
      setDateError("The date is needed.");
      valid = false;
    }

    if (!valid || !edgeInfo || !tazInfo) return;

    const request: SynthEdgesRequest = {
      type: "synth_edges",
      edgeDataId: edgeInfo.fileId,
      tazFileId: tazInfo.fileId,
      newFileName: newName,
      dateString: selectedDate,
    };

    synthFilePost.postSynthEdges(FileType.SynthEdges, request);
    console.log("Filename:", newName);
  }, [newName, selectedDate]);

  useEffect(() => {
    console.log(synthFilePost.fileInfo);
    if (synthFilePost.fileInfo) {
      synthDownload
        .downloadFile(synthFilePost.fileInfo.fileId)
        .then((_) => setSuccess(true));
    }
  }, [synthFilePost.fileInfo]);

  const handleDismissMessage = () => {
    setSuccess(false);
    setNewName("");
    setSelectedDate("");
    setEdgeInfo(null);
    setTazInfo(null);
  };

  return (
    <div>
      {synthFilePost.loading && (
        <MessageOverlay
          type={"loader"}
          message="Generating Synth Edge file, it may take a while."
        />
      )}
      {success && (
        <MessageOverlay
          type="success"
          message="File successfully generated."
          onDismiss={handleDismissMessage}
        />
      )}
      <h1 className="text-2xl font-semibold mb-4">Edge Dataset Generation</h1>
      <p className="text-base leading-relaxed w-3/4">
        In this section you can merge data from an XML edge file and a TAZ file
        to generate a dataset that includes information about traffic volume,
        density, speed, and TAZ zones for each edge, in csv format.
        <p>The date indicates the date the datasete refers to.</p>
        <p>
          Specifically, the{" "}
          <span className="text-green-700">Edge XML File</span> is the file that
          SUMO outputs containing the edge data of the simulation.
        </p>
        <p>You can learn more about edge data on the SUMO documentation.</p>
        <p>
          Instead, the <span className="text-green-700">TAZ XML File</span> is
          the file that contains information about district and is outputed by
          the netedit SUMO utility.
        </p>
      </p>

      <form className="space-y-4 py-8">
        <FileSelector
          fileType={FileType.EdgeData}
          label={"Edge XML File"}
          projectId={1}
          fileInfo={edgeInfo}
          setFileInfo={setEdgeInfo}
          loadingMessage="Uploading Edge XML File"
        />
        <FileSelector
          fileType={FileType.Taz}
          label={"TAZ XML File"}
          projectId={1}
          fileInfo={tazInfo}
          setFileInfo={setTazInfo}
          loadingMessage="Uploading TAZ XML File"
        />
        {edgeInfo != null && tazInfo != null && (
          <>
            <DatePicker
              value={selectedDate}
              onDateSelected={handleDateSelected}
            />
            {dateError && (
              <p className="text-red-500 text-sm mt-1">{dateError}</p>
            )}
            <input
              type="text"
              id="filename"
              placeholder="Specify the new file name here."
              value={newName}
              className={`block my-4 w-3/4 border rounded shadow-sm px-4 py-2 focus:ring-green-500 focus:border-green-500 transition-all
            ${nameError ? "border-red-500" : "border-gray-300"}`}
              onChange={(e) => {
                setNewName(e.target.value);
                if (nameError) setNameError(null);
              }}
            />
            {nameError && (
              <p className="text-red-500 text-sm mt-1">{nameError}</p>
            )}
            <Button
              label="Generate Edge CSV"
              onClick={handleSubmit}
              enabled={edgeInfo != null && tazInfo != null}
            />
          </>
        )}
      </form>
    </div>
  );
};

export default EdgeGeneration;
