import { useCallback, useEffect, useState } from "react";
import Button from "../../components/Button";
import DatePicker from "../../components/DatePicker";
import FilteredMultiSelect from "../../components/FilteredMultiSelect";
import { useFileDownload } from "../../hooks/useFileDownload";
import { useFilePost } from "../../hooks/useFilePost";
import {
  FileInfo,
  FileType,
  FullFileInfoFileData,
  SynthTripsRequest,
  TripTypes,
} from "../../api/generated";
import MessageOverlay from "../../components/MessageOverlay";
import FileSelector from "../../components/FileSelector";

const TripGeneration = () => {
  const synthFilePost = useFilePost();
  const synthDownload = useFileDownload();
  const [tripFileInfo, setTripFileInfo] = useState<FileInfo | null>(null);
  const [tripFileData, setTripFileData] = useState<FullFileInfoFileData | null>(
    null
  );
  const [newName, setNewName] = useState<string>("");
  const [selectedTripTypes, setSelectedTripTypes] = useState<string[]>([]);
  const [nameError, setNameError] = useState<string | null>(null);
  const [dateError, setDateError] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [success, setSuccess] = useState(false);

  const handleDateSelected = (dateStr: string) => {
    const date = new Date(dateStr);
    if (dateError) setDateError(null);
    if (isNaN(date.getTime())) {
      setDateError("Invalide date selected");
      console.error("Invalid date selected");
      return;
    }

    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    const formatted = `${year}-${month}-${day}`;
    console.log("Formatted date:", formatted);
    setSelectedDate(formatted);
  };

  const handleSubmit = useCallback(() => {
    let valid = true;

    if (!newName.trim()) {
      setNameError("The filename for the new file is needed.");
      valid = false;
    }
    if (selectedDate.trim() === "") {
      setDateError("The date is needed.");
      valid = false;
    }

    if (!valid || !tripFileInfo) return;

    const request: SynthTripsRequest = {
      type: "synth_trips",
      tripFileId: tripFileInfo.fileId,
      newFileName: newName,
      dateString: selectedDate,
      selectedTypes: selectedTripTypes,
    };

    synthFilePost.postSynthTrips(FileType.SynthTrips, request);
    console.log("Filename:", newName);
  }, [newName, selectedDate, selectedTripTypes]);

  useEffect(() => {
    console.log(synthFilePost.fileInfo);
    if (synthFilePost.fileInfo) {
      synthDownload
        .downloadFile(synthFilePost.fileInfo.fileId)
        .then((_) => setSuccess(true));
    }
  }, [synthFilePost.fileInfo]);

  const handleDismissMessage = () => {
    setSuccess(false);
    setNewName("");
    setSelectedDate("");
    setTripFileInfo(null);
    setTripFileData(null);
  };

  useEffect(() => {
    console.log("tripFileInfo ", tripFileInfo);
  }, [tripFileInfo]);
  useEffect(() => {
    console.log("tripFileData ", tripFileData);
  }, [tripFileData]);

  return (
    <div>
      {synthFilePost.loading && (
        <MessageOverlay
          type={"loader"}
          message="Generating Synth Trip file, it may take a while."
        />
      )}
      {success && (
        <MessageOverlay
          type="success"
          message="File successfully generated."
          onDismiss={handleDismissMessage}
        />
      )}
      <h1 className="text-2xl font-semibold mb-4">Trip Dataset Generation</h1>
      <p className="text-base leading-relaxed w-3/4">
        This sections allows you to generates a dataset of trips by filtering
        and processing data from an XML file containing trip information.
      </p>
      <p>The date will be combined with trip start and end times.</p>
      <p>
        The requested <span className="text-green-700">Trips XML File</span> is
        the SUMO tripinfo output file.{" "}
        <a
          href="https://sumo.dlr.de/docs/Simulation/Output/TripInfo.html"
          target="_blank"
          className="text-green-700 hover:underline"
        >
          Read more about this file on SUMO Documentation
        </a>
      </p>
      <form className="space-y-4 py-8">
        <FileSelector
          fileType={FileType.TripData}
          label={"Trips XML File"}
          projectId={1}
          fileInfo={tripFileInfo}
          setFileInfo={setTripFileInfo}
          setFileData={setTripFileData}
          loadingMessage="Uploading the Trip File"
          retrievingMessage="Retrieving the trip types"
          withRetrieve
        />
        {tripFileData && (
          <>
            <p className="font-semibold">Select types to include in CSV</p>
            <FilteredMultiSelect
              options={(tripFileData as TripTypes).types}
              validationError={null}
              selectedItems={selectedTripTypes}
              setSelectedItems={setSelectedTripTypes}
              getOptionLabel={function (option: string): string {
                return option;
              }}
            />
            <DatePicker
              label="Select date for depart and arrival"
              value={""}
              onDateSelected={handleDateSelected}
            />
            <input
              type="text"
              id="filename"
              placeholder="Specify the new file name here."
              value={newName}
              className={`block my-4 w-3/4 border rounded shadow-sm px-4 py-2 focus:ring-green-500 focus:border-green-500 transition-all
            ${nameError ? "border-red-500" : "border-gray-300"}`}
              onChange={(e) => {
                setNewName(e.target.value);
                if (nameError) setNameError(null);
              }}
            />
            {nameError && (
              <p className="text-red-500 text-sm mt-1">{nameError}</p>
            )}
            <Button label="Generate CSV" onClick={handleSubmit} />
          </>
        )}
      </form>
    </div>
  );
};

export default TripGeneration;
