import { useEffect, useState } from "react";
import FileCarousel from "../../components/FileCarousel";
import { useProjectRetrieve } from "../../hooks/useProjectRetrieve";
import { FileType } from "../../api/generated";
import { useFileDownload } from "../../hooks/useFileDownload";
import MessageOverlay from "../../components/MessageOverlay";
import { FaSyncAlt } from "react-icons/fa";
import { useFileDelete } from "../../hooks/useFileDelete";

const FileDashboardPage = () => {
  const project = useProjectRetrieve();
  const download = useFileDownload();
  const del = useFileDelete();
  const [globalFilter, setGlobalFilter] = useState("");
  const [showDownloadedMessage, setShowDownloadedMessage] = useState(false);
  const [showDeletedMessage, setShowDeletedMessage] = useState(false);
  const [expandedCardId, setExpandedCardId] = useState<number | null>(null);
  const [isReloading, setIsReloading] = useState(false);

  const reloadFiles = async () => {
    setIsReloading(true);
    await project.retrieveProjectFiles(1);
    setTimeout(() => setIsReloading(false), 1000); // small delay to show animation
  };

  useEffect(() => {
    reloadFiles();
  }, []);

  const handleDeleteFile = (fileId: number) => {
    del.deleteFile(fileId).then((_) => {
      setShowDeletedMessage(true);
      reloadFiles();
    });
  };

  const handleDownloadFile = (fileId: number) => {
    download.downloadFile(fileId).then((_) => setShowDownloadedMessage(true));
  };

  const handleDismissMessage = () => {
    setShowDeletedMessage(false);
    setShowDownloadedMessage(false);
    setExpandedCardId(null);
    download.resetFileDownload();
    del.resetDeleteFile();
  };

  const getLabel = (fileType: FileType) => {
    switch (fileType) {
      case "gtfs":
        return "GTFS Zip Files";
      case "network":
        return "Netowrk Files";
      case "odmatrix":
        return "OD Matrix Files";
      case "roadClosure":
        return "Road Closure Files";
      case "edgeData":
        return "Edge Data Files";
      case "stopData":
        return "Stop Data Files";
      case "tripData":
        return "Trip Data Files";
      case "stopSim":
        return "Simulated Stop Files";
      case "TAZ":
        return "TAZ Files";
      case "synthTrips":
        return "Synthetic Trips Dataset Files";
      case "synthEdges":
        return "Synthetic Edges Dataset Files";
      case "synthStops":
        return "Synthetic Stops Dataset Files";
    }
  };

  return (
    <div className="p-8 space-y-12 overflow-y-auto">
      {download.loading && (
        <MessageOverlay type="loader" message="Downloading file" />
      )}
      {del.loading && <MessageOverlay type="loader" message="Deleting file" />}
      {showDownloadedMessage && (
        <MessageOverlay
          type="success"
          message="File Successfully downloaded"
          onDismiss={handleDismissMessage}
        />
      )}
      {showDeletedMessage && (
        <MessageOverlay
          type="success"
          message="File Successfully deleted"
          onDismiss={handleDismissMessage}
        />
      )}
      <div
        className="flex justify-between items-center mb-8"
        style={{ maxWidth: "94%" }}
      >
        <div className="flex items-center space-x-3">
          <h1 className="text-2xl font-semibold">Dashboard</h1>
          <button onClick={reloadFiles}>
            <FaSyncAlt
              className={`text-xl transition-transform ${
                isReloading ? "animate-spin" : ""
              }`}
            />
          </button>
        </div>
        <input
          type="text"
          placeholder="Search all files by name..."
          value={globalFilter}
          onChange={(e) => setGlobalFilter(e.target.value)}
          className="border rounded px-4 py-2 text-sm w-full max-w-md shadow"
        />
      </div>

      {Object.values(FileType).map((fileType) => (
        <FileCarousel
          key={fileType}
          title={`${getLabel(fileType)}`}
          files={
            project.files?.filter((file) => file.fileType === fileType) ?? []
          }
          globalFilter={globalFilter}
          expandedCardId={expandedCardId}
          setExpandedCardId={setExpandedCardId}
          onDelete={handleDeleteFile}
          onDownload={handleDownloadFile}
        />
      ))}
    </div>
  );
};

export default FileDashboardPage;
