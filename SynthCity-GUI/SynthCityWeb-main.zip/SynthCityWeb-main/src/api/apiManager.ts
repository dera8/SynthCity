import { Configuration } from "./generated/configuration";
import { DownloadApi } from "./generated/api";
import { FileApi } from "./generated/api";
import { ProjectApi } from "./generated/api";
import { UploadApi } from "./generated/api";

export class ApiManager {
  private static instance: ApiManager;
  private configuration: Configuration;

  public readonly downloadApi: DownloadApi;
  public readonly fileApi: FileApi;
  public readonly projectApi: ProjectApi;
  public readonly uploadApi: UploadApi;

  private constructor(configuration?: Configuration) {
    this.configuration =
      configuration ||
      new Configuration({
        baseOptions: {
          headers: {
            Accept: "application/json, application/octet-stream",
          },
        },
      });
    this.downloadApi = new DownloadApi(this.configuration);
    this.fileApi = new FileApi(this.configuration);
    this.projectApi = new ProjectApi(this.configuration);
    this.uploadApi = new UploadApi(this.configuration);
  }

  public static getInstance(configuration?: Configuration): ApiManager {
    if (!ApiManager.instance) {
      ApiManager.instance = new ApiManager(configuration);
    }
    return ApiManager.instance;
  }

  public setBasePath(basePath: string): void {
    this.configuration.basePath = basePath;
  }

  public getBasePath(): string {
    return this.configuration.basePath || "http://127.0.0.1:8000";
  }
}

// Export a default instance
export const apiManager = ApiManager.getInstance();

// Set base path
apiManager.setBasePath("http://127.0.0.1:8000");
