const GENERIC_MESSAGE = "An error occured.";
export class ApiError extends Error {
  statusCode: number;
  message: string;

  constructor(statusCode: number, message: string) {
    super(message);
    this.name = "ApiError";
    this.statusCode = statusCode;
    this.message = message;
    Object.setPrototypeOf(this, ApiError.prototype);
  }

  static wrapError(error: any) {
    if (error.response) {
      const status = error.response.status;
      const message = error.response.data.message || GENERIC_MESSAGE;
      return new ApiError(status, message);
    } else {
      return new ApiError(500, GENERIC_MESSAGE);
    }
  }
}
