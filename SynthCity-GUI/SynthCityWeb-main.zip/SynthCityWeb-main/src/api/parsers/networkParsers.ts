import { LatLngExpression } from "leaflet";
import { Coordinates } from "../generated";

export const coordinatesArrayParser = (
  coordinates: Coordinates[]
): LatLngExpression[] => {
  return coordinates.map((coordinate) => coordinatesParser(coordinate));
};

export const coordinatesParser = (
  coordinate: Coordinates
): LatLngExpression => {
  return [coordinate.latitude, coordinate.longitude];
};
